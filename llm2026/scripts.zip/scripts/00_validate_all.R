#!/usr/bin/env Rscript

# ------------------------------------------------------------------------------
# Workshop 2 Validation Script
# ------------------------------------------------------------------------------
#
# This script deliberately runs fixture-capable demos in `--fixtures` mode. It is for checking
# that files, parsers, and generated artifacts still work without spending API
# credits. The OpenAlex MCP demo is live-only and is checked separately.

# ------------------------------------------------------------------------------
# 0. Locate and load shared helper functions
# ------------------------------------------------------------------------------

args0 <- commandArgs(FALSE)
file_arg0 <- grep("^--file=", args0, value = TRUE)
this_file0 <- if (length(file_arg0)) {
  normalizePath(gsub("~\\+~", " ", sub("^--file=", "", file_arg0[[1]])), mustWork = FALSE)
} else {
  file.path(getwd(), "00_validate_all.R")
}
source(file.path(dirname(this_file0), "helpers.R"))

paths <- ensure_demo_dirs()

# Run a script in fixture mode and stop if it fails.
run_script <- function(script_name) {
  script <- file.path(paths$r, script_name)
  if (!file.exists(script)) {
    stop("Missing script: ", script, call. = FALSE)
  }
  cat("\n== Running ", script_name, " ==\n", sep = "")
  status <- system2(file.path(R.home("bin"), "Rscript"), c(shQuote(script), "--fixtures"))
  if (!identical(status, 0L)) {
    stop("Script failed: ", script_name, call. = FALSE)
  }
  invisible(TRUE)
}

# Store validation checks as a small data frame so they can be saved.
check <- function(name, expr) {
  passed <- isTRUE(expr)
  data.frame(check = name, passed = passed, stringsAsFactors = FALSE)
}

# ------------------------------------------------------------------------------
# 1. Regenerate all demo outputs in deterministic fixture mode
# ------------------------------------------------------------------------------

scripts <- c(
  "01_prepare_anes_data.R",
  "02_anes_prompt_demos.R",
  "03_questionnaire_rag.R",
  "05_sampling_tool_demo.R"
)

for (script in scripts) {
  run_script(script)
}

# ------------------------------------------------------------------------------
# 2. Inspect generated outputs for expected evidence
# ------------------------------------------------------------------------------

labelled <- read_csv_file(file.path(paths$outputs, "anes_republican_likes_labelled.csv"))
prompt_summary <- read_csv_file(file.path(paths$outputs, "prompt_optimisation_summary.csv"))
rag_hits <- read_csv_file(file.path(paths$outputs, "rag_hit_summary.csv"))
question_blocks <- read_csv_file(file.path(paths$outputs, "rag_question_blocks.csv"))
sampling_validation <- read_csv_file(file.path(paths$outputs, "sampling_tool_validation.csv"))

checks <- do.call(rbind, list(
  check("anes_labelled_rows", nrow(labelled) == 8),
  check("anes_codebook_categories", nrow(read_csv_file(file.path(paths$outputs, "anes_republican_likes_codebook.csv"))) == 5),
  check("prompt_v3_accuracy_one", any(prompt_summary$prompt_variant == "prompt_v3" & as.numeric(prompt_summary$accuracy) == 1)),
  check("prompt_outputs_include_structured", file.exists(file.path(paths$outputs, "structured_evaluation_metadata.json"))),
  check("rag_contains_jbhas", any(question_blocks$question_id == "currentemployment_w17.JBHAS")),
  check("rag_contains_jboff", any(question_blocks$question_id == "currentemployment_w17.JBOFF")),
  check("rag_question_block_hit_all_queries", all(rag_hits$hit_at_3[rag_hits$store_type == "question_block"] == TRUE)),
  check("openalex_demo_is_live_only", file.exists(file.path(paths$r, "04_openalex_mcp_demo.R"))),
  check("sampling_tool_checks_passed", all(sampling_validation$passed == TRUE))
))

# ------------------------------------------------------------------------------
# 3. Save and print validation summary
# ------------------------------------------------------------------------------

summary_path <- file.path(paths$outputs, "validation_summary.csv")
write_csv_file(checks, summary_path)

cat("\n== Validation Summary ==\n")
print(checks, row.names = FALSE)

if (!all(checks$passed)) {
  failed <- checks$check[!checks$passed]
  stop("Validation failed: ", paste(failed, collapse = ", "), call. = FALSE)
}

cat("\nAll workshop 2 demo validations passed.\n")
cat("- ", summary_path, "\n", sep = "")
