#!/usr/bin/env Rscript

# ------------------------------------------------------------------------------
# Workshop 2 Setup: prepare the labelled ANES demo data
# ------------------------------------------------------------------------------
#
# This script reads the large ABJK_Declarations.RData file and extracts a small
# labelled teaching dataset from `mydata$replikes.orig`.
#
# It does not call any API. It prepares the data used by 02_anes_prompt_demos.R.

# ------------------------------------------------------------------------------
# 0. Locate and load shared helper functions
# ------------------------------------------------------------------------------

args0 <- commandArgs(FALSE)
file_arg0 <- grep("^--file=", args0, value = TRUE)
this_file0 <- if (length(file_arg0)) {
  normalizePath(gsub("~\\+~", " ", sub("^--file=", "", file_arg0[[1]])), mustWork = FALSE)
} else {
  file.path(getwd(), "01_prepare_anes_data.R")
}
source(file.path(dirname(this_file0), "helpers.R"))

paths <- ensure_demo_dirs()
args <- script_args()

# ------------------------------------------------------------------------------
# 1. Load `mydata` from ABJK_Declarations.RData
# ------------------------------------------------------------------------------
#
# The RData file contains many fitted models and intermediate objects. We load it
# into a temporary environment so the global workspace is not flooded with all of
# those objects. Then we pull out only `mydata`.

load_anes_mydata <- function(paths) {
  rdata_path <- file.path(paths$data, "ABJK_Declarations.RData")
  if (!file.exists(rdata_path)) {
    stop("Missing required data file: ", rdata_path, call. = FALSE)
  }
  env <- new.env(parent = emptyenv())
  suppressWarnings(load(rdata_path, envir = env))
  if (!exists("mydata", envir = env, inherits = FALSE)) {
    stop("ABJK_Declarations.RData did not contain object `mydata`.", call. = FALSE)
  }
  env$mydata
}

# Find one real response matching a text pattern and attach its teaching label.
# These are the eight examples listed in the workshop notes.
find_one_response <- function(texts, pattern, expected_category, expected_mixed, label) {
  matches <- grep(pattern, texts, ignore.case = TRUE, perl = TRUE)
  if (!length(matches)) {
    stop("Could not find labelled ANES response for pattern: ", pattern, call. = FALSE)
  }
  i <- matches[[1]]
  data.frame(
    id = label,
    source_row = i,
    input = texts[[i]],
    expected_category = expected_category,
    expected_category_label = category_codebook()$label[[expected_category]],
    expected_mixed = expected_mixed,
    stringsAsFactors = FALSE
  )
}

# ------------------------------------------------------------------------------
# 2. Extract the open-ended Republican-likes responses
# ------------------------------------------------------------------------------

mydata <- load_anes_mydata(paths)
if (!"replikes.orig" %in% names(mydata)) {
  stop("`mydata` does not include `replikes.orig`.", call. = FALSE)
}

texts <- as.character(mydata$replikes.orig)
texts <- texts[!is.na(texts) & nzchar(texts)]

# ------------------------------------------------------------------------------
# 3. Build the labelled teaching set
# ------------------------------------------------------------------------------
#
# The expected categories correspond to:
#   1 Economic
#   2 Defense
#   3 Social/Moral
#   4 Party Image/Loyalty
#   5 Social Welfare

labelled <- do.call(rbind, list(
  find_one_response(texts, "^Budget minded", 1, FALSE, "RLIKE_01"),
  find_one_response(texts, "Republican party encourages private competition", 1, FALSE, "RLIKE_02"),
  find_one_response(texts, "^They are more fiscally responsible", 1, FALSE, "RLIKE_03"),
  find_one_response(texts, "^They have tried to help in some ways", 5, TRUE, "RLIKE_04"),
  find_one_response(texts, "identified with successful people", 4, FALSE, "RLIKE_05"),
  find_one_response(texts, "^I like the strong defense", 2, FALSE, "RLIKE_06"),
  find_one_response(texts, "conservative approach in moral and economic issues", 3, FALSE, "RLIKE_07"),
  find_one_response(texts, "^Its organization", 4, FALSE, "RLIKE_08")
))

# A small response pool is useful if you want to swap in extra examples during
# the live session.
pool <- data.frame(
  id = sprintf("POOL_%05d", seq_along(texts)),
  input = texts,
  nchar = nchar(texts),
  stringsAsFactors = FALSE
)
pool <- pool[pool$nchar >= 20 & pool$nchar <= 600, , drop = FALSE]
pool <- utils::head(pool, 200)

labelled_path <- file.path(paths$outputs, "anes_republican_likes_labelled.csv")
pool_path <- file.path(paths$outputs, "anes_republican_likes_pool.csv")
codebook_path <- file.path(paths$outputs, "anes_republican_likes_codebook.csv")

# ------------------------------------------------------------------------------
# 4. Save the prepared teaching files
# ------------------------------------------------------------------------------

write_csv_file(labelled, labelled_path)
write_csv_file(pool, pool_path)
write_csv_file(category_codebook(), codebook_path)

cat("Prepared ANES Republican likes demo data.\n")
cat("- ", labelled_path, " (", nrow(labelled), " labelled examples)\n", sep = "")
cat("- ", pool_path, " (", nrow(pool), " response pool examples)\n", sep = "")
cat("- ", codebook_path, "\n", sep = "")
