#!/usr/bin/env Rscript

# ------------------------------------------------------------------------------
# API calls, structured output, and prompt stability
# ------------------------------------------------------------------------------
#
# This script uses a small labelled set of ANES open-ended responses about what
# respondents like about the Republican Party.
#
# It creates five artifacts:
# 1. ordinary chat output versus structured output;
# 2. low-temperature versus high-temperature repeated runs;
# 3. repeated structured-output runs for prompt stability;
# 4. prompt-variant scoring, like a simple evaluation harness;
# 5. structured-output metadata that is easier to inspect and score.
#
# By default this script runs live API calls through OpenRouter. 
#
# If you need a no-network rehearsal or automated validation, run with
# `--fixtures`. Fixture mode generates deterministic example outputs and does
# not call the API.
#
# Example:
#   Rscript --vanilla "workshop 2/R/02_anes_prompt_demos.R"          # live
#   Rscript --vanilla "workshop 2/R/02_anes_prompt_demos.R" --fixtures

# ------------------------------------------------------------------------------
# 0. Locate and load shared helper functions
# ------------------------------------------------------------------------------
#
# R behaves differently when a file is run with Rscript versus opened/sourced in
# RStudio. With Rscript, `commandArgs(FALSE)` usually includes a `--file=...`
# argument. When sourced interactively, it may not. The fallback below assumes the
# current working directory is the folder containing this script.

args0 <- commandArgs(FALSE)
file_arg0 <- grep("^--file=", args0, value = TRUE)
this_file0 <- if (length(file_arg0)) {
  normalizePath(gsub("~\\+~", " ", sub("^--file=", "", file_arg0[[1]])), mustWork = FALSE)
} else {
  file.path(getwd(), "02_anes_prompt_demos.R")
}
source(file.path(dirname(this_file0), "helpers.R"))

# `ensure_demo_dirs()` returns a list of useful paths and creates output folders.
# `fixtures` is now opt-in. In an interactive RStudio run, `args` is usually
# empty, so `fixtures` will be FALSE and the code will make real API calls.
paths <- ensure_demo_dirs()
args <- script_args()
fixtures <- "--fixtures" %in% args

# ------------------------------------------------------------------------------
# 1. Load the labelled ANES data
# ------------------------------------------------------------------------------
#
# The preparation script extracts eight labelled examples from:
#   workshop 2/data/ABJK_Declarations.RData
#
# The labelled data has:
#   id
#   input
#   expected_category
#   expected_category_label
#   expected_mixed

labelled_path <- file.path(paths$outputs, "anes_republican_likes_labelled.csv")
if (!file.exists(labelled_path)) {
  status <- system2(file.path(R.home("bin"), "Rscript"), file.path(paths$r, "01_prepare_anes_data.R"))
  if (!identical(status, 0L)) {
    stop("Failed to prepare ANES data.", call. = FALSE)
  }
}

labelled <- read_csv_file(labelled_path)
cb_text <- codebook_text()

# ------------------------------------------------------------------------------
# 2. Define prompt variants
# ------------------------------------------------------------------------------
#
# prompt_v1 is deliberately underspecified. It asks for "the category" but gives
# no codebook or output contract. This is useful because models often return prose
# that is hard to parse and score.
#
# prompt_v2 adds a codebook and explicit JSON instructions. This is closer to a
# real survey-coding protocol.
#
# prompt_v3 is the more careful version used for prompt-variant scoring. It makes
# the coding rule more explicit and asks for one strict JSON object.

prompt_for_variant <- function(text, variant) {
  if (variant == "prompt_v1") {
    return(sprintf(
      "Classify what political concept this survey respondent likes about the Republican Party. Give me the category: \"%s\"",
      text
    ))
  }
  if (variant == "prompt_v2") {
    return(sprintf(
      paste(
        "You are an advanced quantitative text-coding engine working on American National Election Studies (ANES) data.",
        "Analyze the open-ended text response and assign the single most appropriate Category ID from the codebook below.",
        "",
        "Codebook:",
        cb_text,
        "",
        "Strict Processing Rules:",
        "1. Primary Intent Rule: If multiple categories are mentioned, select the category that occupies the first sentence or the majority of the text.",
        "2. Contradiction Rule: If a response contains both a like and a dislike, code based on the opening statement but set mixed_valence to true.",
        "3. Output Format: Output strictly a JSON object with category_id, mixed_valence, confidence, and evidence.",
        "",
        "User Input: \"%s\"",
        sep = "\n"
      ),
      text
    ))
  }
  sprintf(
    paste(
      "You are a careful ANES open-ended response coder.",
      "Task: classify one thing the respondent likes about the Republican Party.",
      "",
      "Allowed categories:",
      cb_text,
      "",
      "Rules:",
      "- Choose exactly one category.",
      "- If the opening sentence and later text point to different categories, prefer the opening sentence.",
      "- If the respondent also states a dislike or reservation, set mixed_valence to true.",
      "- Return only JSON with category_id, mixed_valence, confidence, and evidence.",
      "",
      "Response: \"%s\"",
      sep = "\n"
    ),
    text
  )
}

# ------------------------------------------------------------------------------
# 3. Parse model output back into variables
# ------------------------------------------------------------------------------
#
# To note:
# If you ask for ordinary text, you need fragile parsing code like this. If you
# use structured output, the model output is already close to a data row.
#
# This parser first tries JSON. If that fails, it searches free text for a
# category id. That fallback is intentionally less reliable than structured
# output.
#
# The important thing is the parsing trace:
#   - Did the model return JSON?
#   - Did we have to use a regex over prose?
#   - Did parsing fail entirely?
#
# This is the point about ordinary chat: A text answer is not yet a coded variable. You still need a parser!!

parse_category_trace <- function(raw_output) {
  parsed <- parse_json_object(raw_output)
  if (is.null(parsed$.parse_error) && !is.null(parsed$category_id)) {
    return(list(
      category_id = as.integer(parsed$category_id),
      parse_method = "json_object",
      parse_note = "Parsed category_id from a JSON object."
    ))
  }
  m <- regexpr("ID\\s*[:#-]?\\s*[1-5]|category[_ ]?id\\D*[1-5]|\\b[1-5]\\b", raw_output, ignore.case = TRUE, perl = TRUE)
  if (m[[1]] < 0) {
    return(list(
      category_id = NA_integer_,
      parse_method = "failed",
      parse_note = "Could not find a category id in the free-text output."
    ))
  }
  digits <- regmatches(raw_output, m)
  list(
    category_id = as.integer(regmatches(digits, regexpr("[1-5]", digits))),
    parse_method = "regex_from_free_text",
    parse_note = "Used a regular expression to pull a number from prose."
  )
}

parse_category_id <- function(raw_output) {
  parse_category_trace(raw_output)$category_id
}

# ------------------------------------------------------------------------------
# 4. Fixture-mode predictions
# ------------------------------------------------------------------------------
#
# Fixture mode is a deterministic stand-in for live API output. It makes the
# script rehearseable and avoids spending API credits during validation.
#
# The small lookup tables below deliberately make weaker prompts perform worse.
# This keeps the evaluation idea visible even without a live model:
#   prompt_v1 < prompt_v2 < prompt_v3

fixture_prediction <- function(row, variant, run = 1, temperature = 0) {
  expected <- as.integer(row$expected_category)
  predicted <- expected
  if (variant == "prompt_v1") {
    lookup <- c(RLIKE_01 = 2, RLIKE_04 = 1, RLIKE_07 = 1)
    predicted <- if (row$id %in% names(lookup)) as.integer(lookup[[row$id]]) else expected
  } else if (variant == "prompt_v2") {
    lookup <- c(RLIKE_04 = 1)
    predicted <- if (row$id %in% names(lookup)) as.integer(lookup[[row$id]]) else expected
  }
  classification <- heuristic_classify_replikes(row$input, prompt_variant = variant, run = run, temperature = temperature)
  classification$category_id <- predicted
  classification$category_label <- category_codebook()$label[[predicted]]
  classification$mixed_valence <- if (variant == "prompt_v1") FALSE else as.logical(row$expected_mixed)
  classification
}

# ------------------------------------------------------------------------------
# 5. Classify one case
# ------------------------------------------------------------------------------
#
# This is the central function in the script. Each call:
#   1. builds the prompt;
#   2. either creates a fixture response or calls OpenRouter;
#   3. parses the output;
#   4. returns one row of logged evidence.
#
# API-call parameters worth inspecting
# ------------------------------------------------
# In live mode the actual HTTP request is made through ellmer's OpenRouter
# provider. The lower-level `openrouter_chat()` helper remains available in
# `helpers.R` for inspecting the raw request mechanics.
#
# Important parameters:
#
# - `model`
#     Which model to use. Here it comes from `OPENROUTER_MODEL`, defaulting to
#     `openai/gpt-4.1-mini`. In ellmer this is the `model = ...` argument.
#
# - `system_prompt`
#     Instructions that define the model's role and high-level behavior. In
#     ellmer this is usually `system_prompt = ...` in `chat_openai()`.
#
# - `prompt`
#     The respondent-specific user message. This is the text sent to `$chat()` or
#     `$chat_structured()` in ellmer.
#
# - `temperature`
#     Controls randomness in generation. Lower values are more repeatable; higher
#     values can vary more. In ellmer this is set with:
#       params = ellmer::params(temperature = ...)
#
# - `seed`
#     Helps repeatability where the provider/model supports it. In ellmer:
#       params = ellmer::params(seed = ...)
#
# - `max_tokens`
#     Caps output length. This matters for cost, verbosity, and truncation risk.
#     In ellmer:
#       params = ellmer::params(max_tokens = ...)
#
# - `response_format`
#     The structured-output contract. Here we pass a JSON schema through
#     OpenRouter. In ellmer, the equivalent is:
#       chat$chat_structured(prompt, type = ellmer::type_object(...))
#
# - `tools` and `tool_choice`
#     Not used in this prompt-coding script, but used in tool examples. In ellmer you
#     register tools with `chat$register_tool(...)`; provider-specific forcing
#     can be passed through API arguments where supported.
#
# - `paths`
#     Local bookkeeping only. It tells the helper where `.env` and output folders
#     live. This is not an LLM parameter.
#


classify_case <- function(row, variant, structured = FALSE, run = 1, temperature = 0, seed = 123) {
  prompt <- prompt_for_variant(row$input, variant)
  model <- Sys.getenv("OPENROUTER_MODEL", "openai/gpt-4.1-mini")

  # Fixture mode: no network call. We simulate what a model might return.
  if (fixtures) {
    classification <- fixture_prediction(row, variant, run = run, temperature = temperature)
    raw_output <- if (structured) format_structured_fixture_output(classification) else format_default_fixture_output(classification)
    parsed <- if (structured) parse_json_object(raw_output) else parse_category_trace(raw_output)
    usage <- list(prompt_tokens = NA_integer_, completion_tokens = NA_integer_)
    model_snapshot <- "fixture"
  } else {
    # Live mode: call OpenRouter through ellmer.
    #
    # For structured output, create a JSON schema. The schema says the response
    # must contain `category_id`, `mixed_valence`, `confidence`, and `evidence`.
    # This is the OpenRouter/OpenAI-style equivalent of an ellmer type contract.
    response_format <- if (structured) json_schema_response_format("anes_republican_like_classification", classification_schema()) else NULL

    # The runnable path uses ellmer. For ordinary chat, `$chat()` returns text.
    # For structured output, `$chat_structured()` returns an R list that already
    # has the requested fields. `response_format` above is kept as the raw
    # OpenRouter schema that would be sent without ellmer's type helper.
    response <- if (structured) {
      ellmer_structured_chat(
        prompt = prompt,
        type = ellmer_classification_type(),
        system_prompt = "You classify ANES open-ended survey responses. Follow the requested output contract exactly.",
        temperature = temperature,
        seed = seed,
        max_tokens = 180,
        paths = paths
      )
    } else {
      ellmer_openrouter_chat(
        prompt = prompt,
        system_prompt = "You classify ANES open-ended survey responses. Follow the requested output contract exactly.",
        temperature = temperature,
        seed = seed,
        max_tokens = 220,
        paths = paths
      )
    }
    raw_output <- response$content
    parsed <- if (structured) response$structured else parse_category_trace(raw_output)
    usage <- response$usage
    model_snapshot <- response$model %||% model
  }

  # Return one logged row. This is what makes the API call reproducible: input,
  # prompt variant, model, parameters, raw output, parsed output, and score.
  category_id <- as.integer(parsed$category_id %||% NA_integer_)
  parse_method <- if (structured) "json_schema_contract" else parsed$parse_method %||% "unknown"
  parse_note <- if (structured) "Structured output returned fields defined by the JSON schema." else parsed$parse_note %||% NA_character_
  parse_valid <- is.null(parsed$.parse_error) && !is.na(category_id)
  data.frame(
    id = row$id,
    mode = if (structured) "structured_output" else "ordinary_chat",
    prompt_variant = variant,
    run = run,
    client = if (fixtures) "fixture" else response$client %||% "ellmer_openrouter",
    model = if (fixtures) "fixture" else "openrouter",
    model_snapshot = model_snapshot,
    temperature = temperature,
    seed = seed %||% NA_integer_,
    expected_category = as.integer(row$expected_category),
    predicted_category = category_id,
    expected_mixed = as.logical(row$expected_mixed),
    predicted_mixed = as.logical(parsed$mixed_valence %||% NA),
    confidence = as.numeric(parsed$confidence %||% NA_real_),
    evidence = as.character(parsed$evidence %||% NA_character_),
    parse_method = parse_method,
    parse_note = parse_note,
    parse_valid = parse_valid,
    correct = !is.na(category_id) && category_id == as.integer(row$expected_category),
    input_tokens = usage$prompt_tokens %||% NA_integer_,
    output_tokens = usage$completion_tokens %||% NA_integer_,
    raw_output = raw_output,
    stringsAsFactors = FALSE
  )
}

# ------------------------------------------------------------------------------
# 6. Ordinary chat versus structured output
# ------------------------------------------------------------------------------
#
# Same cases, two modes:
#   - prompt_v1 as ordinary chat;
#   - prompt_v2 as structured JSON.
#
# The visible contrast is that ordinary chat can be hard to parse, while structured
# output gives data-like fields.

run_default_vs_structured <- function(data) {
  rows <- lapply(seq_len(nrow(data)), function(i) {
    row <- data[i, , drop = FALSE]
    rbind(
      classify_case(row, "prompt_v1", structured = FALSE, temperature = 0),
      classify_case(row, "prompt_v2", structured = TRUE, temperature = 0)
    )
  })
  do.call(rbind, rows)
}

# This creates a small table for the ordinary-chat half of the first
# comparison. Open this after `default_vs_structured <- run_default_vs_structured(...)`.
#
# What to look for:
#   - `raw_output` is prose, not a variable.
#   - `parse_method` tells you whether the parser had to use a regex or failed.
#   - `predicted_category` is a post-processing artifact, not something the API guaranteed.
#   - Structured output avoids this fragile parser step.

make_default_parsing_demo <- function(default_vs_structured) {
  ordinary <- default_vs_structured[default_vs_structured$mode == "ordinary_chat", , drop = FALSE]
  ordinary[, c(
    "id",
    "raw_output",
    "parse_method",
    "parse_note",
    "parse_valid",
    "predicted_category",
    "expected_category",
    "correct"
  )]
}

# ------------------------------------------------------------------------------
# 7. Generation parameters
# ------------------------------------------------------------------------------
#
# Run the same case five times at low and high temperature.
#
# In fixture mode the output is deterministic but still logs the parameters. In
# live mode, this demonstrates that randomness settings are part of the research
# design, not hidden chat-product behavior.
#
# Case choice matters for what this demo shows. A clear-cut response (e.g. the
# "Budget minded" economic case) will be coded the same way at every temperature,
# so the demo would look like temperature does nothing. We deliberately use an
# ambiguous case -- RLIKE_07 mentions both "moral" and "economic" issues, so it
# sits between the Social/Moral and Economic categories -- where high temperature
# is more likely to flip the predicted label across runs. Swap the id below back
# to "RLIKE_01" if you want to show the opposite (a stable, easy case).

run_parameter_demo <- function(data) {
  row <- data[data$id == "RLIKE_07", , drop = FALSE]
  rows <- list()
  idx <- 1
  for (setting in c("low_temperature", "high_temperature")) {
    temperature <- if (setting == "low_temperature") 0 else 1
    seed <- if (setting == "low_temperature") 123 else NA_integer_
    for (run in 1:5) {
      rows[[idx]] <- classify_case(row, "prompt_v1", structured = FALSE, run = run, temperature = temperature, seed = seed)
      rows[[idx]]$setting <- setting
      idx <- idx + 1
    }
  }
  out <- do.call(rbind, rows)
  out[, c("setting", setdiff(names(out), "setting"))]
}

# ------------------------------------------------------------------------------
# 8. Repeated structured-output runs for prompt stability
# ------------------------------------------------------------------------------
#
# For classification tasks, reproducibility is not just "does the model generate
# the same sentence?" It is "does the same case get the same label?"

run_stability_demo <- function(data) {
  cases <- data[data$id %in% c("RLIKE_01", "RLIKE_04", "RLIKE_05", "RLIKE_06", "RLIKE_07"), , drop = FALSE]
  rows <- list()
  idx <- 1
  for (run in 1:5) {
    for (i in seq_len(nrow(cases))) {
      rows[[idx]] <- classify_case(cases[i, , drop = FALSE], "prompt_v2", structured = TRUE, run = run, temperature = 1, seed = NA_integer_)
      idx <- idx + 1
    }
  }
  do.call(rbind, rows)
}

# ------------------------------------------------------------------------------
# 9. Evaluation-driven prompt optimisation
# ------------------------------------------------------------------------------
#
# This is not automatic prompt search. It is a simple evaluation loop:
#   1. define candidate prompts;
#   2. run them on labelled data;
#   3. score outputs against expected labels;
#   4. keep the prompt you can defend with evidence.
#
# The first function keeps the mechanics visible with simple data frames. The
# companion vitals example below expresses the same comparison as:
#   dataset + solver + scorer.

run_prompt_optimisation <- function(data) {
  variants <- c("prompt_v1", "prompt_v2", "prompt_v3")
  rows <- list()
  idx <- 1
  for (variant in variants) {
    for (i in seq_len(nrow(data))) {
      rows[[idx]] <- classify_case(data[i, , drop = FALSE], variant, structured = variant != "prompt_v1", temperature = 0)
      idx <- idx + 1
    }
  }
  predictions <- do.call(rbind, rows)
  summary <- aggregate(correct ~ prompt_variant, predictions, function(x) c(n = length(x), correct = sum(x), accuracy = mean(x)))
  summary <- do.call(data.frame, summary)
  names(summary) <- c("prompt_variant", "n", "correct", "accuracy")
  summary$accuracy <- round(summary$accuracy, 3)
  list(predictions = predictions, summary = summary)
}

make_vitals_prompt_dataset <- function(data) {
  variants <- c("prompt_v1", "prompt_v2", "prompt_v3")
  rows <- list()
  idx <- 1
  for (variant in variants) {
    for (i in seq_len(nrow(data))) {
      row <- data[i, , drop = FALSE]
      rows[[idx]] <- data.frame(
        id = paste(row$id, variant, sep = "_"),
        case_id = row$id,
        prompt_variant = variant,
        structured = variant != "prompt_v1",
        input = prompt_for_variant(row$input, variant),
        target = as.character(row$expected_category),
        expected_category = as.integer(row$expected_category),
        expected_mixed = as.logical(row$expected_mixed),
        response_text = row$input,
        stringsAsFactors = FALSE
      )
      idx <- idx + 1
    }
  }
  do.call(rbind, rows)
}

vitals_prompt_solver <- function(eval_dataset) {
  function(inputs, ...) {
    results <- character(length(inputs))
    solver_chats <- vector("list", length(inputs))
    solver_metadata <- vector("list", length(inputs))

    for (i in seq_along(inputs)) {
      row <- eval_dataset[match(inputs[[i]], eval_dataset$input), , drop = FALSE]
      if (!nrow(row)) {
        stop("Could not match vitals input back to the prompt dataset.", call. = FALSE)
      }

      # vitals 0.1.0 logs plain chat turns cleanly. The prompt_v2 and prompt_v3
      # inputs still request JSON; the scorer checks whether the result can be
      # parsed and whether the parsed category matches the target.
      response <- ellmer_openrouter_chat(
        prompt = inputs[[i]],
        system_prompt = "You classify ANES open-ended survey responses. Follow the requested output contract exactly.",
        temperature = 0,
        seed = 123,
        max_tokens = if (isTRUE(row$structured)) 180 else 220,
        paths = paths
      )
      parsed <- if (isTRUE(row$structured)) parse_json_object(response$content) else parse_category_trace(response$content)

      results[[i]] <- response$content
      solver_chats[[i]] <- response$chat
      solver_metadata[[i]] <- list(
        client = response$client,
        model = response$model,
        prompt_variant = row$prompt_variant,
        category_id = as.integer(parsed$category_id %||% NA_integer_),
        mixed_valence = as.logical(parsed$mixed_valence %||% NA),
        confidence = as.numeric(parsed$confidence %||% NA_real_)
      )
    }

    list(
      result = results,
      solver_chat = solver_chats,
      solver_metadata = solver_metadata
    )
  }
}

vitals_exact_category_scorer <- function() {
  function(samples) {
    scores <- character(nrow(samples))
    metadata <- vector("list", nrow(samples))

    for (i in seq_len(nrow(samples))) {
      row <- samples[i, , drop = FALSE]
      parsed <- if (identical(row$prompt_variant, "prompt_v1")) {
        parse_category_trace(row$result)
      } else {
        parse_json_object(row$result)
      }
      predicted <- as.integer(parsed$category_id %||% NA_integer_)
      expected <- as.integer(row$target)
      scores[[i]] <- if (!is.na(predicted) && predicted == expected) "C" else "I"
      metadata[[i]] <- list(
        predicted_category = predicted,
        expected_category = expected,
        parse_method = if (identical(row$prompt_variant, "prompt_v1")) parsed$parse_method %||% "unknown" else "json_object",
        parse_valid = is.null(parsed$.parse_error) && !is.na(predicted)
      )
    }

    list(
      score = factor(scores, levels = c("I", "C"), ordered = TRUE),
      scorer_metadata = metadata
    )
  }
}

run_vitals_prompt_optimisation <- function(data) {
  if (fixtures) {
    return(NULL)
  }
  if (!requireNamespace("vitals", quietly = TRUE)) {
    return(NULL)
  }

  eval_dataset <- make_vitals_prompt_dataset(data)
  log_dir <- file.path(paths$outputs, "vitals_logs")
  dir.create(log_dir, recursive = TRUE, showWarnings = FALSE)

  task <- vitals::Task$new(
    dataset = eval_dataset,
    solver = vitals_prompt_solver(eval_dataset),
    scorer = vitals_exact_category_scorer(),
    metrics = list(accuracy = function(score) mean(score == "C")),
    name = "ANES prompt optimisation with vitals",
    dir = log_dir
  )
  task$eval(view = FALSE)

  samples <- as.data.frame(task$get_samples(), stringsAsFactors = FALSE)
  parsed <- lapply(seq_len(nrow(samples)), function(i) {
    row <- samples[i, , drop = FALSE]
    if (identical(row$prompt_variant, "prompt_v1")) {
      parse_category_trace(row$result)
    } else {
      parse_json_object(row$result)
    }
  })

  predictions <- data.frame(
    id = samples$case_id,
    vitals_id = samples$id,
    prompt_variant = samples$prompt_variant,
    client = "ellmer_openrouter",
    model = Sys.getenv("OPENROUTER_MODEL", "openai/gpt-4.1-mini"),
    expected_category = as.integer(samples$target),
    predicted_category = vapply(parsed, function(x) as.integer(x$category_id %||% NA_integer_), integer(1)),
    score = as.character(samples$score),
    correct = as.character(samples$score) == "C",
    raw_output = samples$result,
    stringsAsFactors = FALSE
  )

  summary <- aggregate(correct ~ prompt_variant, predictions, function(x) c(n = length(x), correct = sum(x), accuracy = mean(x)))
  summary <- do.call(data.frame, summary)
  names(summary) <- c("prompt_variant", "n", "correct", "accuracy")
  summary$accuracy <- round(summary$accuracy, 3)

  list(
    task = task,
    predictions = predictions,
    summary = summary,
    log_dir = log_dir
  )
}

# ------------------------------------------------------------------------------
# 10. Run all prompt examples
# ------------------------------------------------------------------------------
#
# Heads-up on cost in live mode. Each of the blocks below makes its own batch of
# API calls, and they add up quickly:
#   - default vs structured:      8 cases x 2 modes  = 16 calls
#   - parameter (temperature):    1 case  x 10 runs  = 10 calls
#   - stability:                  5 cases x 5 runs   = 25 calls
#   - prompt optimisation:        3 prompts x 8 cases = 24 calls
#   - vitals optimisation:        3 prompts x 8 cases = 24 calls (if installed)
# That is roughly 75-100 OpenRouter calls per full live run. For a classroom with
# shared or limited credits, consider running a subset, lowering the run counts,
# or rehearsing with --fixtures first.

default_vs_structured <- run_default_vs_structured(labelled)
default_parsing_demo <- make_default_parsing_demo(default_vs_structured)
parameter_runs <- run_parameter_demo(labelled)
stability_runs <- run_stability_demo(labelled)
optimisation <- run_prompt_optimisation(labelled)
vitals_optimisation <- run_vitals_prompt_optimisation(labelled)

# ------------------------------------------------------------------------------
# 11. Store structured-output metadata
# ------------------------------------------------------------------------------
#
# This is where structured output helps evaluation: the thing being scored is a variable (`category_id`), not a paragraph.

structured_metadata <- list(
  task_shape = list(dataset = "input + target", solver = "ellmer OpenRouter chat_structured in live mode; deterministic fixture solver in fixture mode", scorer = "exact category_id match"),
  codebook = category_codebook(),
  samples = lapply(seq_len(nrow(default_vs_structured[default_vs_structured$mode == "structured_output", , drop = FALSE])), function(i) {
    row <- default_vs_structured[default_vs_structured$mode == "structured_output", , drop = FALSE][i, , drop = FALSE]
    list(
      id = row$id,
      expected_category = row$expected_category,
      predicted_category = row$predicted_category,
      predicted_mixed = row$predicted_mixed,
      raw_structured_output = row$raw_output
    )
  })
)

# ------------------------------------------------------------------------------
# 12. Write CSV/JSON artifacts
# ------------------------------------------------------------------------------
#
# These files are the audit trail.

write_csv_file(default_vs_structured, file.path(paths$outputs, "prompt_default_vs_structured.csv"))
write_csv_file(default_parsing_demo, file.path(paths$outputs, "prompt_default_parsing_demo.csv"))
write_csv_file(parameter_runs, file.path(paths$outputs, "prompt_parameter_runs.csv"))
write_csv_file(stability_runs, file.path(paths$outputs, "prompt_stability_runs.csv"))
write_csv_file(optimisation$predictions, file.path(paths$outputs, "prompt_optimisation_predictions.csv"))
write_csv_file(optimisation$summary, file.path(paths$outputs, "prompt_optimisation_summary.csv"))
if (!is.null(vitals_optimisation)) {
  write_csv_file(vitals_optimisation$predictions, file.path(paths$outputs, "prompt_vitals_optimisation_predictions.csv"))
  write_csv_file(vitals_optimisation$summary, file.path(paths$outputs, "prompt_vitals_optimisation_summary.csv"))
}
write_json_file(structured_metadata, file.path(paths$outputs, "structured_evaluation_metadata.json"))

stability_summary <- aggregate(predicted_category ~ id, stability_runs, function(x) paste(sort(unique(x)), collapse = ","))
names(stability_summary)[[2]] <- "unique_predicted_categories"
write_csv_file(stability_summary, file.path(paths$outputs, "prompt_stability_summary.csv"))

# ------------------------------------------------------------------------------
# 13. Write a short Markdown report for summary
# ------------------------------------------------------------------------------

report <- c(
  "# ANES Prompt Outputs",
  "",
  paste0("Mode: ", if (fixtures) "fixtures" else "live OpenRouter via ellmer"),
  "",
  "## Structured Output",
  "",
  "Structured output turns a formatting request into an output contract. Here the same ANES coding task is run as ordinary chat and as JSON-constrained output.",
  "",
  "## Ordinary Chat Requires Parsing",
  "",
  "The ordinary-chat output is a text string. To turn it into the classification variable we need, the script has to run a post-processing parser. See `prompt_default_parsing_demo.csv` for raw output, parsing method, parser note, parsed category, and correctness.",
  "",
  "## Prompt Optimisation Summary",
  "",
  paste(capture.output(print(optimisation$summary, row.names = FALSE)), collapse = "\n"),
  "",
  "## vitals Prompt Optimisation Summary",
  "",
  if (!is.null(vitals_optimisation)) {
    paste(capture.output(print(vitals_optimisation$summary, row.names = FALSE)), collapse = "\n")
  } else {
    "The vitals example was not run because fixture mode was active or the package was not installed."
  },
  "",
  "## Prompt Stability Summary",
  "",
  paste(capture.output(print(stability_summary, row.names = FALSE)), collapse = "\n"),
  "",
  "## Files",
  "",
  "- `prompt_default_vs_structured.csv`",
  "- `prompt_default_parsing_demo.csv`",
  "- `prompt_parameter_runs.csv`",
  "- `prompt_stability_runs.csv`",
  "- `prompt_optimisation_predictions.csv`",
  "- `prompt_optimisation_summary.csv`",
  if (!is.null(vitals_optimisation)) "- `prompt_vitals_optimisation_predictions.csv`" else character(),
  if (!is.null(vitals_optimisation)) "- `prompt_vitals_optimisation_summary.csv`" else character(),
  "- `structured_evaluation_metadata.json`"
)
writeLines(report, file.path(paths$outputs, "prompt_demos_report.md"))

cat("Wrote ANES prompt outputs to ", paths$outputs, "\n", sep = "")
print(optimisation$summary, row.names = FALSE)
