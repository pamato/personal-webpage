#!/usr/bin/env Rscript

# ------------------------------------------------------------------------------
# RAG over a survey questionnaire
# ------------------------------------------------------------------------------
#
# This script shows that retrieval design matters. It builds three
# retrieval stores over the Understanding Society Wave 17 questionnaire:
#
# 1. naive fixed-size chunks;
# 2. markdown-like chunks, one per parsed question block;
# 3. questionnaire-aware chunks with question id, variable name, universe,
#    routing, response options, and source page.
#
# By default, the retrieval answers are generated live with OpenRouter. Use
# `--fixtures` only when you want deterministic, no-network rehearsal output.

# ------------------------------------------------------------------------------
# 0. Locate and load shared helper functions
# ------------------------------------------------------------------------------

args0 <- commandArgs(FALSE)
file_arg0 <- grep("^--file=", args0, value = TRUE)
this_file0 <- if (length(file_arg0)) {
  normalizePath(gsub("~\\+~", " ", sub("^--file=", "", file_arg0[[1]])), mustWork = FALSE)
} else {
  file.path(getwd(), "03_questionnaire_rag.R")
}
source(file.path(dirname(this_file0), "helpers.R"))

# Live mode is the default. `--fixtures` is the explicit fallback.
paths <- ensure_demo_dirs()
args <- script_args()
fixtures <- "--fixtures" %in% args

# ------------------------------------------------------------------------------
# 1. Extract questionnaire text from the PDF
# ------------------------------------------------------------------------------
#
# The script uses `pdftools` if installed, otherwise it uses the command-line
# `pdftotext` utility. The extracted text is cached under outputs/pdf_text so
# repeated runs are much faster.

pdf_path <- file.path(paths$data, "6614-main-survey-questionnaire-w17.pdf")
if (!file.exists(pdf_path)) {
  stop("Missing Understanding Society questionnaire PDF: ", pdf_path, call. = FALSE)
}

txt_path <- file.path(paths$outputs, "pdf_text", "6614-main-survey-questionnaire-w17.txt")
invisible(extract_pdf_text(pdf_path, txt_path))
pages <- read_pdf_pages(txt_path)
full_text <- paste(pages, collapse = "\n\n")

# ------------------------------------------------------------------------------
# 2. Parse question blocks
# ------------------------------------------------------------------------------
#
# `parse_question_blocks()` turns the questionnaire into one row per question.
# Each row contains fields that are meaningful for survey instruments:
# question id, variable name, module, universe, routing, response options, and
# page. This is the "questionnaire-aware" retrieval unit.

question_blocks_path <- file.path(paths$outputs, "rag_question_blocks.csv")
if (file.exists(question_blocks_path)) {
  question_blocks <- read_csv_file(question_blocks_path)
} else {
  question_blocks <- parse_question_blocks(pages)
  if (!nrow(question_blocks)) {
    stop("No question blocks could be parsed from the questionnaire PDF.", call. = FALSE)
  }
  write_csv_file(question_blocks, question_blocks_path)
}

# ------------------------------------------------------------------------------
# 3. Build three retrieval stores
# ------------------------------------------------------------------------------
#
# Store 1: naive chunks split text every 1,000 characters.
# Store 2: markdown-like chunks based on question blocks.
# Store 3: questionnaire-aware question blocks.

naive_chunks <- make_fixed_chunks(full_text, chunk_size = 1000, overlap = 150, prefix = "naive")
markdown_chunks <- make_markdown_like_chunks(question_blocks)

# `stores` is a named list so the same retrieval loop can be run over all three chunking strategies.
stores <- list(
  naive = naive_chunks,
  markdown_like = markdown_chunks,
  question_block = question_blocks
)

# The three stores have different metadata columns. This helper makes them share
# a common schema before they are combined into one comparison table.
standardize_retrieval <- function(x) {
  wanted <- c(
    "query_id", "query", "store_type", "strategy", "rank", "chunk_id", "chunk_type",
    "context", "wave", "module", "module_group", "respondent_type", "question_id",
    "variable_name", "source_page", "bm25", "cosine_distance", "hybrid_score",
    "target_hit", "universe", "routing_before", "question_text", "response_options",
    "text"
  )
  for (name in setdiff(wanted, names(x))) {
    x[[name]] <- NA
  }
  x[, wanted, drop = FALSE]
}

# These queries deliberately include exact variable names
# because questionnaires often depend on exact identifiers and routing.
queries <- data.frame(
  query_id = c("who_jbhas", "options_jbhas", "route_jboff", "economic_activity_vars"),
  query = c(
    "In the Understanding Society questionnaire, who is asked currentemployment_w17.JBHAS?",
    "What are the response options for variable JBHAS?",
    "What routing condition leads to question currentemployment_w17.JBOFF?",
    "Which variables capture current economic activity, paid work last week, or whether the respondent has a job?"
  ),
  target = c("currentemployment_w17.JBHAS", "JBHAS", "currentemployment_w17.JBOFF", "JBHAS|JBOFF|JULK4WK|JULKJB|JUBGN"),
  stringsAsFactors = FALSE
)



# ------------------------------------------------------------------------------
# 4. Retrieve top chunks from each store
# ------------------------------------------------------------------------------
#
# `retrieve_chunks()` is a transparent local retrieval function from helpers.R.
# It scores term overlap and cosine-like similarity so you can inspect the
# retrieved text before seeing any generated answer.

retrieval_rows <- list()
idx <- 1
for (query_i in seq_len(nrow(queries))) {
  query <- queries$query[[query_i]]
  target <- queries$target[[query_i]]
  for (store_name in names(stores)) {
    retrieved <- retrieve_chunks(stores[[store_name]], query, top_k = 3, strategy = "hybrid")
    retrieved$query_id <- queries$query_id[[query_i]]
    retrieved$query <- query
    retrieved$store_type <- store_name
    retrieved$strategy <- "hybrid"
    retrieved$rank <- seq_len(nrow(retrieved))
    retrieved$target_hit <- grepl(target, retrieved$text, ignore.case = TRUE, perl = TRUE)
    retrieval_rows[[idx]] <- standardize_retrieval(retrieved)
    idx <- idx + 1
  }
}
retrieval_comparison <- do.call(rbind, retrieval_rows)
write_csv_file(retrieval_comparison, file.path(paths$outputs, "rag_retrieval_comparison.csv"))

# The hit summary is the a check: did the right variable/question appear in the top 3 retrieved chunks?
hit_summary <- aggregate(target_hit ~ query_id + store_type, retrieval_comparison, any)
names(hit_summary)[[3]] <- "hit_at_3"
write_csv_file(hit_summary, file.path(paths$outputs, "rag_hit_summary.csv"))

# ------------------------------------------------------------------------------
# 5. Compare retrieval strategies on question-block chunks
# ------------------------------------------------------------------------------
#
# Dense/vector-style retrieval and lexical/BM25-style retrieval have different
# strengths. Questionnaires often benefit from exact identifier matching, so BM25
# can be very useful for variables such as JBHAS or JBOFF.

strategy_rows <- list()
idx <- 1
for (strategy in c("vss", "bm25", "hybrid")) {
  for (query_i in seq_len(nrow(queries))) {
    retrieved <- retrieve_chunks(question_blocks, queries$query[[query_i]], top_k = 3, strategy = strategy)
    retrieved$strategy <- strategy
    retrieved$query_id <- queries$query_id[[query_i]]
    retrieved$rank <- seq_len(nrow(retrieved))
    strategy_rows[[idx]] <- retrieved
    idx <- idx + 1
  }
}
strategy_comparison <- do.call(rbind, strategy_rows)
write_csv_file(strategy_comparison, file.path(paths$outputs, "rag_strategy_comparison.csv"))

# ------------------------------------------------------------------------------
# 6. Metadata filtering
# ------------------------------------------------------------------------------
#
# Metadata is part of research design. Before retrieving, we restrict the search
# to wave 17, adult respondents, and employment-related modules.

metadata_filtered <- question_blocks[
  question_blocks$wave == "wave_17" &
    question_blocks$respondent_type == "adult" &
    question_blocks$module_group %in% c("currentemployment", "nonemployment"),
  ,
  drop = FALSE
]
metadata_query <- "paid work last week has paid job looked for work"
metadata_retrieved <- retrieve_chunks(metadata_filtered, metadata_query, top_k = 8, strategy = "hybrid")
write_csv_file(metadata_retrieved, file.path(paths$outputs, "rag_metadata_filter_demo.csv"))

# ------------------------------------------------------------------------------
# 7. Build an extractive answer for the fixture fallback
# ------------------------------------------------------------------------------
#
# This answer is not used as the live model answer. It is a deterministic fallback
# for `--fixtures`, and it gives a human-readable benchmark for the live response.

jbhas <- question_blocks[question_blocks$question_id == "currentemployment_w17.JBHAS", , drop = FALSE]
jboff <- question_blocks[question_blocks$question_id == "currentemployment_w17.JBOFF", , drop = FALSE]
extractive_answer <- if (nrow(jbhas)) {
  paste(
    "`currentemployment_w17.JBHAS` is asked to all respondents. It asks whether they did any paid work last week, including employee or self-employed work, casual work, Saturday jobs, or earning money through a website or digital platform. The response options are `1 Yes` and `2 No`.",
    if (nrow(jboff)) "`currentemployment_w17.JBOFF` is routed after `if [JBHAS = 2]`, meaning it is asked when the respondent did not do paid work last week." else "",
    sep = "\n\n"
  )
} else {
  "The expected `currentemployment_w17.JBHAS` block was not found in parsed question blocks."
}

# ------------------------------------------------------------------------------
# 8. Write an overall RAG report
# ------------------------------------------------------------------------------

report_path <- file.path(paths$outputs, "rag_questionnaire_report.md")
report <- c(
  "# Questionnaire RAG",
  "",
  paste0("Mode: ", if (fixtures) "fixtures/extractive" else "live OpenRouter answer generation via ellmer"),
  "",
  "## Retrieval Claim",
  "",
  "For RAG, the unit of retrieval should match the unit of meaning. In a questionnaire, that is often a question block plus routing and response metadata.",
  "",
  "## Hit Summary",
  "",
  paste(capture.output(print(hit_summary, row.names = FALSE)), collapse = "\n"),
  "",
  "## Metadata Filter",
  "",
  "The metadata-filtered retrieval restricts to `wave_17`, adult respondent type, and the current/non-employment module groups before searching.",
  "",
  "## Extractive Answer From Question-Block Retrieval",
  "",
  extractive_answer,
  "",
  "## Files",
  "",
  "- `rag_question_blocks.csv`",
  "- `rag_retrieval_comparison.csv`",
  "- `rag_hit_summary.csv`",
  "- `rag_strategy_comparison.csv`",
  "- `rag_metadata_filter_demo.csv`"
)
writeLines(report, report_path)

# ------------------------------------------------------------------------------
# 9. Write one markdown file per query/store combination
# ------------------------------------------------------------------------------
#
# These are the files to open when inspecting what the retriever actually selected.

for (query_i in seq_len(nrow(queries))) {
  query_id <- queries$query_id[[query_i]]
  for (store_name in names(stores)) {
    retrieved <- retrieval_comparison[
      retrieval_comparison$query_id == query_id & retrieval_comparison$store_type == store_name,
      ,
      drop = FALSE
    ]
    answer <- if (store_name == "question_block" && query_id %in% c("who_jbhas", "options_jbhas", "route_jboff")) extractive_answer else NULL
    lines <- render_retrieval_markdown(
      title = paste("RAG Retrieval", query_id, store_name),
      query = queries$query[[query_i]],
      retrieved = retrieved,
      answer = answer
    )
    writeLines(lines, file.path(paths$outputs, "rag", paste0(query_id, "_", store_name, ".md")))
  }
}

# ------------------------------------------------------------------------------
# 10. Generate live OpenRouter answers from retrieved question blocks
# ------------------------------------------------------------------------------
#
# This is the RAG generation step. For each query:
#   1. retrieve top question-block chunks;
#   2. paste the retrieved context into the prompt;
#   3. ask OpenRouter through ellmer to answer using only that context;
#   4. save the model answer to `rag_live_openrouter_answers.csv`.
#
# API parameters worth showing:
#   - `system_prompt`: tells the model to answer only from retrieved context.
#   - `temperature = 0`: keeps answers as deterministic as the provider allows.
#   - `seed = 123`: asks for repeatability where supported.
#   - `max_tokens = 350`: caps answer length.


# ------------------------------------------------------------------------------
# Live RAG comparison: all questions x all retrieval stores
# ------------------------------------------------------------------------------

# Same three stores as above; reuse the list rather than redefining it so the two
# comparisons can never drift out of sync.
stores_to_compare <- stores

live_rows <- list()
context_rows <- list()
idx <- 1
context_idx <- 1

for (query_i in seq_len(nrow(queries))) {
  query_id <- queries$query_id[[query_i]]
  query_text <- queries$query[[query_i]]
  target <- queries$target[[query_i]]
  
  for (store_name in names(stores_to_compare)) {
    retrieved <- retrieve_chunks(
      chunks = stores_to_compare[[store_name]],
      query = query_text,
      top_k = 4,
      strategy = "hybrid"
    )
    
    # Save retrieved context for inspection.
    retrieved_for_view <- retrieved
    retrieved_for_view$query_id <- query_id
    retrieved_for_view$query <- query_text
    retrieved_for_view$store_type <- store_name
    retrieved_for_view$rank <- seq_len(nrow(retrieved_for_view))
    retrieved_for_view$target_hit <- grepl(
      target,
      retrieved_for_view$text,
      ignore.case = TRUE,
      perl = TRUE
    )
    
    context_rows[[context_idx]] <- standardize_retrieval(retrieved_for_view)
    context_idx <- context_idx + 1
    
    prompt <- paste(
      "Answer the questionnaire question using only the retrieved context.",
      "If the retrieved context does not contain enough evidence, say that the context is insufficient.",
      "",
      "Question:",
      query_text,
      "",
      "Retrieved context:",
      paste(retrieved$text, collapse = "\n\n---\n\n"),
      sep = "\n"
    )
    
    # Honour --fixtures: fixture mode must not touch the network, so 00_validate_all.R
    # can run fully offline. We fall back to the deterministic extractive answer for
    # the question-block store and a clearly-labelled placeholder for the others.
    response <- if (fixtures) {
      fixture_answer <- if (store_name == "question_block") {
        extractive_answer
      } else {
        paste0(
          "[fixture] No live generation. Retrieved ", nrow(retrieved),
          " chunks from the '", store_name, "' store for query '", query_id, "'."
        )
      }
      list(content = fixture_answer, client = "fixture", model = "fixture")
    } else {
      ellmer_openrouter_chat(
        prompt = prompt,
        system_prompt = "You answer survey-instrument questions from retrieved questionnaire context only. Do not use outside knowledge.",
        temperature = 0,
        seed = 123,
        max_tokens = 350,
        paths = paths
      )
    }
    
    live_rows[[idx]] <- data.frame(
      query_id = query_id,
      query = query_text,
      store_type = store_name,
      retrieval_strategy = "hybrid",
      top_k = 4,
      retrieved_chunk_ids = paste(retrieved$chunk_id, collapse = "; "),
      retrieved_target_hit = any(grepl(target, retrieved$text, ignore.case = TRUE, perl = TRUE)),
      client = response$client,
      model = response$model,
      answer = response$content,
      stringsAsFactors = FALSE
    )
    
    idx <- idx + 1
  }
}

live_rag_store_comparison_all <- do.call(rbind, live_rows)
live_rag_contexts_all <- do.call(rbind, context_rows)

if (interactive()) {
  View(live_rag_store_comparison_all)
  View(live_rag_contexts_all)
}

write_csv_file(
  live_rag_store_comparison_all,
  file.path(paths$outputs, "rag_live_store_comparison_all.csv")
)

write_csv_file(
  live_rag_contexts_all,
  file.path(paths$outputs, "rag_live_contexts_all.csv")
)


cat("Wrote questionnaire RAG outputs to ", paths$outputs, "\n", sep = "")
print(
  live_rag_store_comparison_all[, c("query_id", "store_type", "retrieved_target_hit")],
  row.names = FALSE
)
