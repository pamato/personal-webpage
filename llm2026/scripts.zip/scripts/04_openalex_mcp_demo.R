#!/usr/bin/env Rscript

# ------------------------------------------------------------------------------
# Workshop 2 Demo: MCP-style literature search with OpenAlex
# ------------------------------------------------------------------------------
#
# This script demonstrates the difference between:
#   Stage A: asking the model from memory;
#   Stage B: using an external scholarly search tool;
#   Stage C: verifying a suspicious citation.
#   Stage D: wiring the same idea through ellmer + an MCP server.
#
# There is an OpenAlex MCP server project:
#   https://github.com/drAbreu/alex-mcp
#
# That server is designed for MCP-capable hosts and exposes OpenAlex-backed tools
# for author disambiguation and work retrieval. This R script is a live classroom
# analogue: the host-side "tool" boundary is implemented as an R function that
# queries the public OpenAlex API directly, while the model baseline comes from
# OpenRouter. Pedagogically, the point is the same: the model is not remembering
# papers; the host program is querying an external evidence system.
#
# This script is live-only:
#   - ellmer + OpenRouter for the no-tool baseline;
#   - OpenAlex for the tool-backed search and verification.
#   - ellmer + mcptools for the optional live MCP bridge when OPENALEX_MAILTO is set.

# ------------------------------------------------------------------------------
# 0. Locate and load shared helper functions
# ------------------------------------------------------------------------------

args0 <- commandArgs(FALSE)
file_arg0 <- grep("^--file=", args0, value = TRUE)
this_file0 <- if (length(file_arg0)) {
  normalizePath(gsub("~\\+~", " ", sub("^--file=", "", file_arg0[[1]])), mustWork = FALSE)
} else {
  file.path(getwd(), "04_openalex_mcp_demo.R")
}
source(file.path(dirname(this_file0), "helpers.R"))

paths <- ensure_demo_dirs()
args <- script_args()
if ("--fixtures" %in% args) {
  stop(
    "04_openalex_mcp_demo.R is live-only. Remove --fixtures and run with network access, ",
    "ellmer/httr2/jsonlite installed, and an OpenRouter API key in .env.",
    call. = FALSE
  )
}

alex_mcp_repo <- "https://github.com/drAbreu/alex-mcp"
alex_mcp_uvx <- "uvx --from git+https://github.com/drAbreu/alex-mcp.git@4.1.0 python -c 'from alex_mcp.server import mcp; mcp.run()'"

require_live_ellmer_openrouter_for_openalex_demo <- function(paths) {
  load_openrouter_env(paths)
  if (!requireNamespace("ellmer", quietly = TRUE)) {
    stop("ellmer is required for this live OpenRouter demo. Install it with install.packages('ellmer').", call. = FALSE)
  }
  if (!requireNamespace("httr2", quietly = TRUE)) {
    stop("httr2 is required for this live OpenAlex/OpenRouter demo.", call. = FALSE)
  }
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    stop("jsonlite is required for this live OpenAlex/OpenRouter demo.", call. = FALSE)
  }
  if (!nzchar(Sys.getenv("OPENROUTER_API_KEY"))) {
    stop("Set OPENROUTER_API_KEY, OPENROUTER_KEY, key, OPENAI_API_KEY, or API_KEY in .env before running this live demo.", call. = FALSE)
  }
  invisible(TRUE)
}

ellmer_openrouter_chat <- function(prompt,
                                   system_prompt = "You are a careful research assistant.",
                                   temperature = 0,
                                   max_tokens = 300,
                                   paths = workshop_paths()) {
  require_live_ellmer_openrouter_for_openalex_demo(paths)
  chat <- ellmer::chat_openrouter(
    system_prompt = system_prompt,
    model = Sys.getenv("OPENROUTER_MODEL", "openai/gpt-4.1-mini"),
    params = ellmer::params(temperature = temperature, max_tokens = max_tokens),
    echo = "none"
  )
  chat$chat(prompt)
}

ascii_report_text <- function(x) {
  patterns <- vapply(c(0x2018, 0x2019, 0x201C, 0x201D, 0x2013, 0x2014), intToUtf8, character(1))
  replacements <- c("'", "'", "\"", "\"", "-", "-")
  x <- enc2utf8(x)
  for (i in seq_along(patterns)) {
    x <- gsub(patterns[[i]], replacements[[i]], x, fixed = TRUE)
  }
  x <- iconv(x, from = "UTF-8", to = "ASCII//TRANSLIT", sub = "")
  x <- gsub("<U\\+2018>|<U\\+2019>", "'", x)
  x <- gsub("<U\\+201C>|<U\\+201D>", "\"", x)
  x <- gsub("<U\\+2013>|<U\\+2014>", "-", x)
  x
}

# ------------------------------------------------------------------------------
# 1. Define the OpenAlex search tool
# ------------------------------------------------------------------------------
#
# This function is the external tool. It takes a query and returns structured
# bibliographic rows: title, year, DOI, OpenAlex ID, authors, and a note.
#
# In an MCP setup, this function would live behind the MCP server. Here it is
# plain R so students can see exactly what evidence system was queried.

openalex_search <- function(query,
                            from_publication_date = "2023-01-01",
                            per_page = 5,
                            search_mode = c("keyword", "title")) {
  search_mode <- match.arg(search_mode)
  if (!requireNamespace("httr2", quietly = TRUE)) {
    stop("httr2 is required for live OpenAlex search.", call. = FALSE)
  }
  date_filter <- paste0("from_publication_date:", from_publication_date)
  req <- httr2::request("https://api.openalex.org/works")
  req <- if (identical(search_mode, "title")) {
    req |>
      httr2::req_url_query(
        filter = paste0("title.search:", query, ",", date_filter),
        `per-page` = per_page
      )
  } else {
    req |>
      httr2::req_url_query(
        search = query,
        filter = date_filter,
        `per-page` = per_page
      )
  }
  req <- req |>
    httr2::req_headers(`User-Agent` = "ncrm-workshop-demo/0.1")
  response <- httr2::req_perform(req)
  parsed <- httr2::resp_body_json(response, simplifyVector = FALSE)
  results <- parsed$results %||% list()
  rows <- lapply(results, function(work) {
    authors <- vapply(work$authorships %||% list(), function(a) a$author$display_name %||% NA_character_, character(1))
    data.frame(
      source_query = query,
      search_mode = search_mode,
      title = work$title %||% NA_character_,
      year = work$publication_year %||% NA_integer_,
      doi = work$doi %||% NA_character_,
      openalex_id = work$id %||% NA_character_,
      authors = paste(utils::head(stats::na.omit(authors), 5), collapse = "; "),
      relevance_note = "Returned by OpenAlex for the live query; inspect title/abstract before citing.",
      stringsAsFactors = FALSE
    )
  })
  if (!length(rows)) {
    return(data.frame(
      source_query = character(), search_mode = character(),
      title = character(), year = integer(), doi = character(),
      openalex_id = character(), authors = character(), relevance_note = character()
    ))
  }
  do.call(rbind, rows)
}

openalex_title_searches <- function(queries, from_publication_date = "2023-01-01", per_query = 2) {
  rows <- do.call(rbind, lapply(
    queries,
    openalex_search,
    from_publication_date = from_publication_date,
    per_page = per_query,
    search_mode = "title"
  ))
  if (!nrow(rows)) {
    return(rows)
  }
  rows <- rows[!duplicated(trim_ws(tolower(rows$title))), , drop = FALSE]
  utils::head(rows, 5)
}

# ------------------------------------------------------------------------------
# 2. Define the ellmer + MCP wiring
# ------------------------------------------------------------------------------
#
# ellmer is the R client for the LLM. mcptools is the R MCP client that can read
# a Claude-style MCP server config, start those servers, and convert their tools
# into ellmer tools via mcptools::mcp_tools().
#
# In other words:
#   ellmer::chat_openrouter() -> OpenRouter model
#   mcptools::mcp_tools()     -> MCP server tools converted to ellmer tools
#   chat$set_tools(...)       -> OpenRouter model can request those tools
#   R host/mcptools           -> executes tool calls against the MCP server

ellmer_mcp_example_code <- function(config_path) {
  c(
    "library(ellmer)",
    "library(mcptools)",
    "",
    "# The config points mcptools at the alex-mcp stdio server.",
    paste0("config <- ", deparse(config_path)),
    "",
    "chat <- ellmer::chat_openrouter(",
    "  system_prompt = \"Use OpenAlex MCP tools for literature evidence. Do not invent citations.\",",
    "  model = Sys.getenv(\"OPENROUTER_MODEL\", \"openai/gpt-4.1-mini\"),",
    "  echo = \"none\"",
    ")",
    "",
    "chat$set_tools(mcptools::mcp_tools(config = config))",
    "chat$chat(",
    "  \"Use the OpenAlex tools to check whether this title exists: Prompt Stability Scoring for Text Annotation with Large Language Models in Survey Research\"",
    ")"
  )
}

write_alex_mcp_config <- function(path, mailto = Sys.getenv("OPENALEX_MAILTO")) {
  config <- list(
    mcpServers = list(
      `alex-mcp` = list(
        command = "uvx",
        args = c(
          "--from",
          "git+https://github.com/drAbreu/alex-mcp.git@4.1.0",
          "python",
          "-c",
          "from alex_mcp.server import mcp; mcp.run()"
        ),
        env = list(
          OPENALEX_MAILTO = if (nzchar(mailto)) mailto else "replace-with-your-email@domain.com"
        )
      )
    )
  )
  write_json_file(config, path)
  invisible(path)
}

run_ellmer_mcp_demo <- function(config_path, suspicious_title) {
  has_ellmer <- requireNamespace("ellmer", quietly = TRUE)
  has_mcptools <- requireNamespace("mcptools", quietly = TRUE)
  has_vitals <- requireNamespace("vitals", quietly = TRUE)
  has_uvx <- nzchar(Sys.which("uvx"))
  has_mailto <- nzchar(Sys.getenv("OPENALEX_MAILTO"))
  has_openrouter_key <- nzchar(Sys.getenv("OPENROUTER_API_KEY"))
  can_attempt <- has_ellmer && has_mcptools && has_uvx && has_mailto && has_openrouter_key

  result <- data.frame(
    component = c("ellmer", "vitals", "mcptools", "uvx", "OPENALEX_MAILTO", "OPENROUTER_API_KEY", "live_mcp_attempt"),
    available = c(has_ellmer, has_vitals, has_mcptools, has_uvx, has_mailto, has_openrouter_key, can_attempt),
    detail = c(
      if (has_ellmer) "R package is installed." else "Install with install.packages('ellmer').",
      if (has_vitals) "R package is installed." else "Install with install.packages('vitals').",
      if (has_mcptools) "R package is installed." else "Install with install.packages('mcptools').",
      if (has_uvx) Sys.which("uvx") else "Install uv or replace command with a local alex-mcp checkout.",
      if (has_mailto) "Set in environment." else "Set OPENALEX_MAILTO before running alex-mcp.",
      if (has_openrouter_key) "Set in environment." else "Set OPENROUTER_API_KEY or an alias loaded by helpers.R.",
      if (can_attempt) "All local prerequisites present; attempting a live ellmer + MCP call." else "Not attempted; missing one or more local prerequisites."
    ),
    stringsAsFactors = FALSE
  )

  if (!can_attempt) {
    missing <- result$component[!result$available & result$component != "live_mcp_attempt"]
    skip_reason <- paste(
      "Live ellmer + MCP call was not attempted.",
      paste0("Missing prerequisite(s): ", paste(missing, collapse = ", "), "."),
      paste0("Config template was written to: ", config_path),
      "Install/configure the missing prerequisite(s), then rerun this script to make the live MCP call.",
      sep = "\n"
    )
    return(list(status = result, attempted = FALSE, answer = skip_reason))
  }

  answer <- tryCatch({
    chat <- ellmer::chat_openrouter(
      system_prompt = "Use OpenAlex MCP tools for literature evidence. Do not invent citations.",
      model = Sys.getenv("OPENROUTER_MODEL", "openai/gpt-4.1-mini"),
      echo = "none"
    )

    # This is the actual MCP connection point: mcptools reads the config,
    # starts alex-mcp over stdio, discovers its tools, and turns them into
    # ellmer tools that the OpenRouter model can request.
    tools <- mcptools::mcp_tools(config = config_path)
    chat$set_tools(tools)
    chat$chat(
      paste(
        "Use the OpenAlex MCP tools to check whether this title exists:",
        suspicious_title
      )
    )
  }, error = function(e) {
    paste("Live ellmer + MCP call failed:", conditionMessage(e))
  })

  result$detail[result$component == "live_mcp_attempt"] <- "Attempted; see report text for returned answer or error."
  list(status = result, attempted = TRUE, answer = ascii_report_text(answer))
}

# ------------------------------------------------------------------------------
# 3. Citation verification
# ------------------------------------------------------------------------------
#
# This is often a stronger demo than "find papers". We give the system a
# suspicious citation title and ask the tool whether it can be found.

verify_suspicious_citation <- function(title) {
  results <- openalex_search(title, from_publication_date = "2020-01-01", per_page = 5, search_mode = "title")
  exact <- results[trim_ws(tolower(results$title)) == trim_ws(tolower(title)), , drop = FALSE]
  if (nrow(exact)) {
    status <- "exact_match_found"
    closest <- exact$title[[1]]
  } else if (nrow(results)) {
    status <- "no_exact_match_similar_results_found"
    closest <- results$title[[1]]
  } else {
    status <- "not_found"
    closest <- NA_character_
  }
  data.frame(
    suspicious_title = title,
    status = status,
    closest_tool_title = closest,
    evidence = if (nrow(results)) paste(results$title, collapse = " | ") else "OpenAlex returned no works.",
    stringsAsFactors = FALSE
  )
}

# ------------------------------------------------------------------------------
# 4. Stage A: no tool
# ------------------------------------------------------------------------------
#
# This asks OpenRouter directly for citations without using OpenAlex. The point is
# not that the model will always be wrong; the point is that the evidence trail is
# weak because no external source was queried.
#
# API parameters worth showing:
#   - `system_prompt`: explicitly says this is the no-tool baseline.
#   - `temperature = 0.2`: allows a little natural variation.
#   - `max_tokens = 500`: enough room for three short citations.

literature_queries <- c(
  "Do AIs know what the most important issue is",
  "Coding Open-Ended Responses using Pseudo Response Generation",
  "Navigating the Risks of Using Large Language Models for Text Annotation"
)
suspicious_title <- "Prompt Stability Scoring for Text Annotation with Large Language Models in Survey Research"

require_live_ellmer_openrouter_for_openalex_demo(paths)

no_tool_answer <- ellmer_openrouter_chat(
  prompt = "Find three recent papers on using LLMs for survey response coding or text annotation. Give title, authors, year, DOI and one-sentence relevance. Do not use external tools.",
  system_prompt = "Answer from model memory only. This is intentionally the no-tool baseline for a citation-verification demo.",
  temperature = 0.2,
  max_tokens = 500,
  paths = paths
)
no_tool_answer <- ascii_report_text(no_tool_answer)

# ------------------------------------------------------------------------------
# 5. Stage B and C: tool-backed search and verification
# ------------------------------------------------------------------------------
#
# Stage B returns only records from OpenAlex.
# Stage C checks whether the suspicious title is an exact match, a similar result,
# or not found.

tool_results <- openalex_title_searches(literature_queries, per_query = 2)
verification <- verify_suspicious_citation(suspicious_title)

# ------------------------------------------------------------------------------
# 6. Stage D: ellmer + MCP wiring
# ------------------------------------------------------------------------------

ellmer_config_path <- file.path(paths$outputs, "openalex_mcp_ellmer_config.json")

# Write the MCP server config that mcptools will read. If OPENALEX_MAILTO is set,
# this config is immediately runnable. Otherwise it remains an editable template
# and the live MCP attempt below is skipped with an explicit status row.
write_alex_mcp_config(ellmer_config_path)

# This is the live ellmer + MCP attempt. It uses ellmer for OpenRouter and uses
# mcptools::mcp_tools(config = ellmer_config_path) to connect to alex-mcp. The
# helper returns a status table plus the model answer when all prerequisites are
# present.
ellmer_mcp <- run_ellmer_mcp_demo(ellmer_config_path, suspicious_title)

# ------------------------------------------------------------------------------
# 7. Save inspectable outputs
# ------------------------------------------------------------------------------

write_csv_file(tool_results, file.path(paths$outputs, "openalex_tool_results.csv"))
write_csv_file(verification, file.path(paths$outputs, "openalex_verification.csv"))
write_csv_file(ellmer_mcp$status, file.path(paths$outputs, "openalex_mcp_ellmer_status.csv"))

# The markdown report is the file to open during teaching.
report <- c(
  "# OpenAlex MCP Literature Demo",
  "",
  "Mode: live ellmer/OpenRouter + live OpenAlex",
  "",
  "## MCP Server Note",
  "",
  paste0("An OpenAlex MCP server exists at ", alex_mcp_repo, "."),
  paste0("For an MCP-capable client, a current direct-launch command is: `", alex_mcp_uvx, "`."),
  "This R script keeps the tool boundary visible by calling the live OpenAlex works API directly from the host program.",
  "",
  "## Stage A: No Tool",
  "",
  "This baseline uses `ellmer::chat_openrouter()`, not a hand-written OpenRouter request.",
  "",
  no_tool_answer,
  "",
  "## Stage B: Tool-Backed Search",
  "",
  "Only return works actually found by the live OpenAlex title searches.",
  "",
  paste0("Live OpenAlex title queries: ", paste(literature_queries, collapse = " | ")),
  "",
  paste(capture.output(print(tool_results[, c("title", "year", "doi")], row.names = FALSE)), collapse = "\n"),
  "",
  "## Stage C: Suspicious Citation Verification",
  "",
  paste(capture.output(print(verification, row.names = FALSE)), collapse = "\n"),
  "",
  "## Stage D: ellmer + MCP Client Wiring",
  "",
  "This is the actual R-side bridge when you want the OpenRouter model to use tools from an MCP server. ellmer is the LLM client; mcptools is the MCP client. The MCP server does not become the model, and the model still does not call the OpenAlex REST API directly. The R host gives the model tool schemas, receives tool-call requests, and mcptools executes those requests against the MCP server.",
  "",
  paste0("Config template written to: ", ellmer_config_path),
  "",
  "```r",
  ellmer_mcp_example_code(ellmer_config_path),
  "```",
  "",
  "Local live-run status:",
  "",
  paste(capture.output(print(ellmer_mcp$status, row.names = FALSE)), collapse = "\n"),
  "",
  "Live ellmer + MCP answer or skip reason:",
  "",
  ellmer_mcp$answer,
  "",
  "## Teaching Claim",
  "",
  "MCP does not make the model more knowledgeable. It gives the host application a standardised way to expose external capabilities as tools. With ellmer + mcptools + OpenRouter, the host still mediates the call: OpenRouter receives tool schemas, the model requests a tool call, and R/mcptools executes that call through the MCP server."
)
report <- ascii_report_text(report)
writeLines(report, file.path(paths$outputs, "openalex_mcp_demo.md"))

cat("Wrote OpenAlex MCP-style demo outputs to ", paths$outputs, "\n", sep = "")
print(verification, row.names = FALSE)
