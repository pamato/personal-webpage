#!/usr/bin/env Rscript

# ------------------------------------------------------------------------------
# Model answer versus calculation tool
# ------------------------------------------------------------------------------
#
# This script shows why tools matter for numerical/statistical tasks.
#
# Stage 1 asks OpenRouter to answer a sampling-allocation question directly.
# Stage 2 gives OpenRouter access to a registered calculation tool. The model
# decides to call the tool, R performs the calculation, and the tool result is
# sent back to the model for explanation.
#
# By default this script runs live OpenRouter calls. Use `--fixtures` only for
# no-network rehearsal or automated validation.

# ------------------------------------------------------------------------------
# 0. Locate and load shared helper functions
# ------------------------------------------------------------------------------

args0 <- commandArgs(FALSE)
file_arg0 <- grep("^--file=", args0, value = TRUE)
this_file0 <- if (length(file_arg0)) {
  normalizePath(gsub("~\\+~", " ", sub("^--file=", "", file_arg0[[1]])), mustWork = FALSE)
} else {
  file.path(getwd(), "05_sampling_tool_demo.R")
}
source(file.path(dirname(this_file0), "helpers.R"))

paths <- ensure_demo_dirs()
args <- script_args()
fixtures <- "--fixtures" %in% args

# ------------------------------------------------------------------------------
# 1. Data: four survey strata
# ------------------------------------------------------------------------------
#
# N is the population size of each stratum.
# sd is the stratum standard deviation.
# Neyman allocation gives more sample to strata with larger N * sd.

strata <- data.frame(
  stratum = c("A", "B", "C", "D"),
  N = c(1037, 2914, 5183, 11926),
  sd = c(7.3, 13.8, 24.1, 39.6),
  stringsAsFactors = FALSE
)

# A single source of truth for the total sample size. Deliberately NOT a round
# number. Combined with the awkward N and sd values above, none of the
# per-stratum divisions land on tidy figures, so a model doing the arithmetic
# "from memory" reliably drifts off the exact numbers the tool computes. This is
# what makes the no-tool baseline visibly worse than the tool-grounded answer.
total_n <- 803

# Build the user question straight from the data above so the prompt and the
# numbers the tool sees can never drift apart. (Previously the question text was
# hand-typed in four places -- exactly how prompt/data mismatches creep in.)
build_sampling_prompt <- function(strata, total_n, extra = NULL) {
  rows <- paste(
    sprintf(
      "  Stratum %s: N = %d, sd = %s",
      strata$stratum, strata$N, format(strata$sd, trim = TRUE)
    ),
    collapse = "\n"
  )
  paste0(
    "A survey has ", nrow(strata), " strata, with these population sizes (N) ",
    "and standard deviations (sd):\n", rows, "\n",
    "The total sample size is ", total_n, ". ",
    "Calculate the proportional allocation and the Neyman allocation, rounding ",
    "each stratum's allocated sample size to a whole number of respondents. ",
    "Show the allocated sample sizes and explain the difference between the two methods.",
    if (!is.null(extra)) paste0(" ", extra) else ""
  )
}

# Round allocations while preserving the exact total sample size. This avoids the
# common annoyance where rounded strata add to 802 or 804 instead of total_n.
round_allocation <- function(raw, total_n) {
  base <- floor(raw)
  remainder <- total_n - sum(base)
  if (remainder > 0) {
    order_idx <- order(raw - base, decreasing = TRUE)
    base[order_idx[seq_len(remainder)]] <- base[order_idx[seq_len(remainder)]] + 1
  }
  base
}

# This is the calculation tool. It is deliberately small and auditable.
sampling_allocation <- function(total_n = 800) {
  prop_raw <- total_n * strata$N / sum(strata$N)
  neyman_raw <- total_n * strata$N * strata$sd / sum(strata$N * strata$sd)
  data.frame(
    stratum = strata$stratum,
    N = strata$N,
    sd = strata$sd,
    prop_raw = round(prop_raw, 2),
    prop_alloc = round_allocation(prop_raw, total_n),
    neyman_raw = round(neyman_raw, 2),
    neyman_alloc = round_allocation(neyman_raw, total_n),
    stringsAsFactors = FALSE
  )
}

# ------------------------------------------------------------------------------
# 2. Describe the R function as an API tool
# ------------------------------------------------------------------------------
#
# OpenAI/OpenRouter-style tool calling needs a JSON schema describing:
#   - the tool name;
#   - what it does;
#   - what arguments it accepts.
#
# In ellmer, the equivalent move is:
#   tool <- ellmer::tool(sampling_allocation, ...)
#   chat$register_tool(tool)
#
# The raw schema remains here so the OpenRouter request shape is visible. The
# runnable live path below registers the same R function through ellmer.

tool_schema <- list(
  type = "function",
  `function` = list(
    name = "sampling_allocation",
    description = "Calculate proportional and Neyman allocation for the fixed four-stratum example.",
    parameters = list(
      type = "object",
      additionalProperties = FALSE,
      properties = list(
        total_n = list(type = "integer", minimum = 1, description = "Total sample size to allocate.")
      ),
      required = list("total_n")
    )
  )
)

ellmer_sampling_tool <- function(log_env) {
  sampling_allocation_logged <- function(total_n = 800) {
    result <- sampling_allocation(total_n)
    log_env$calls <- c(log_env$calls, list(list(name = "sampling_allocation", arguments = list(total_n = total_n), result = result)))
    result
  }
  ellmer::tool(
    sampling_allocation_logged,
    name = "sampling_allocation",
    description = "Calculate proportional and Neyman allocation for the fixed four-stratum example.",
    arguments = list(
      total_n = ellmer::type_integer("Total sample size to allocate.")
    )
  )
}

python_tool_schema <- list(
  type = "function",
  `function` = list(
    name = "run_python",
    description = "Run Python code and return stdout, stderr, and exit status.",
    parameters = list(
      type = "object",
      additionalProperties = FALSE,
      properties = list(
        code = list(
          type = "string",
          description = "Python code to execute. Print the final computed result clearly."
        )
      ),
      required = list("code")
    )
  )
)

ellmer_python_tool <- function(log_env) {
  run_python_logged <- function(code) {
    result <- run_python_code(code)
    log_env$calls <- c(log_env$calls, list(list(name = "run_python", arguments = list(code = code), result = result)))
    result
  }
  ellmer::tool(
    run_python_logged,
    name = "run_python",
    description = "Run Python code and return stdout, stderr, and exit status.",
    arguments = list(
      code = ellmer::type_string("Python code to execute. Print the final computed result clearly.")
    )
  )
}

run_python_code <- function(code) {
  python <- Sys.which("python3")
  if (!nzchar(python)) {
    python <- Sys.which("python")
  }
  if (!nzchar(python)) {
    stop("No python or python3 executable found.", call. = FALSE)
  }
  script_path <- tempfile(fileext = ".py")
  code_json <- jsonlite::toJSON(code, auto_unbox = TRUE)
  wrapper <- paste(
    "import ast",
    paste0("source = ", code_json),
    "tree = ast.parse(source)",
    "if tree.body and isinstance(tree.body[-1], ast.Expr):",
    "    tree.body[-1] = ast.Expr(value=ast.Call(func=ast.Name(id='print', ctx=ast.Load()), args=[ast.Call(func=ast.Name(id='repr', ctx=ast.Load()), args=[tree.body[-1].value], keywords=[])], keywords=[]))",
    "    ast.fix_missing_locations(tree)",
    "exec(compile(tree, '<run_python_tool>', 'exec'), {})",
    sep = "\n"
  )
  writeLines(wrapper, script_path, useBytes = TRUE)
  output <- system2(python, shQuote(script_path), stdout = TRUE, stderr = TRUE)
  status <- attr(output, "status")
  if (is.null(status)) {
    status <- 0L
  }
  list(
    code = code,
    exit_status = as.integer(status),
    output = paste(output, collapse = "\n")
  )
}

# ------------------------------------------------------------------------------
# 3. Live tool-call loop
# ------------------------------------------------------------------------------
#
# Tool calling is a two-step conversation:
#
# 1. Send the user question plus tool schema to the model.
#    The model returns either a normal answer or a tool call request.
#
# 2. If the model requests a tool call, R executes `sampling_allocation()`.
#    Then we send the tool result back to the model so it can write the final
#    explanation.
#
# API parameters worth inspecting:
#   - `tool_schema`: the lower-level schema sent to OpenRouter without ellmer.
#   - `chat$register_tool(...)`: the ellmer path used below.
#   - `temperature = 0`: reduce randomness.
#   - `max_tokens`: controls response length.

run_live_tool_call <- function(total_n) {
  user_prompt <- build_sampling_prompt(strata, total_n)
  tool_log <- new.env(parent = emptyenv())
  tool_log$calls <- list()
  chat <- ellmer_openrouter_session(
    system_prompt = "For statistical calculations, call the registered tool before answering.",
    temperature = 0,
    max_tokens = 600,
    paths = paths
  )
  chat$register_tool(ellmer_sampling_tool(tool_log))
  answer <- as.character(chat$chat(user_prompt, echo = "none"))
  trace_text <- ellmer_trace_text(chat)
  list(
    answer = answer,
    tool_called = length(tool_log$calls) > 0 || grepl("sampling_allocation", trace_text, fixed = TRUE),
    model = chat$get_model(),
    trace = list(
      chat_trace = trace_text,
      usage = ellmer_usage(chat),
      tool_calls = tool_log$calls
    )
  )
}

run_live_python_tool_call <- function(total_n) {
  user_prompt <- build_sampling_prompt(
    strata, total_n,
    extra = "Use Python to do the arithmetic before answering."
  )
  tool_log <- new.env(parent = emptyenv())
  tool_log$calls <- list()
  chat <- ellmer_openrouter_session(
    system_prompt = "For statistical calculations, write Python code and call run_python before answering. Do not do arithmetic from memory.",
    temperature = 0,
    max_tokens = 700,
    paths = paths
  )
  chat$register_tool(ellmer_python_tool(tool_log))
  answer <- as.character(chat$chat(user_prompt, echo = "none"))
  trace_text <- ellmer_trace_text(chat)
  list(
    answer = answer,
    tool_called = length(tool_log$calls) > 0 || grepl("run_python", trace_text, fixed = TRUE),
    model = chat$get_model(),
    trace = list(
      chat_trace = trace_text,
      usage = ellmer_usage(chat),
      tool_calls = tool_log$calls
    )
  )
}

# ------------------------------------------------------------------------------
# 4. Run the calculation locally
# ------------------------------------------------------------------------------
#
# The local calculation is saved regardless of fixture/live mode. This is the
# ground truth against which the tool-call trace can be checked.

allocation <- sampling_allocation(total_n)
write_csv_file(allocation, file.path(paths$outputs, "sampling_tool_allocation.csv"))

# ------------------------------------------------------------------------------
# 5. Stage 1 and Stage 2 answers
# ------------------------------------------------------------------------------
#
# Fixture mode: deterministic text, no API.
# Live mode:
#   Stage 1 = direct model answer without tools.
#   Stage 2 = model has access to the R calculation tool.

sampling_prompt <- build_sampling_prompt(strata, total_n)

if (fixtures) {
  allocation_text <- paste(capture.output(print(allocation, row.names = FALSE)), collapse = "\n")
  no_tool_response <- list(
    content = "[fixture] Direct model answer omitted. This rehearsal mode does not call OpenRouter.",
    client = "fixture",
    model = "fixture"
  )
  no_tool_answer <- no_tool_response$content

  tool_answer <- paste(
    "[fixture] The registered R tool returned the exact proportional and Neyman allocations:",
    allocation_text,
    sep = "\n"
  )
  live <- list(
    answer = tool_answer,
    tool_called = TRUE,
    model = "fixture",
    trace = list(
      chat_trace = "[fixture] Simulated ellmer tool call for sampling_allocation.",
      usage = list(prompt_tokens = NA_integer_, completion_tokens = NA_integer_),
      tool_calls = list(list(
        name = "sampling_allocation",
        arguments = list(total_n = total_n),
        result = allocation
      ))
    )
  )
  tool_called <- live$tool_called

  fixture_python_code <- paste(
    "N = [1037, 2914, 5183, 11926]",
    "sd = [7.3, 13.8, 24.1, 39.6]",
    "total_n = 803",
    "print('Proportional allocation: 39, 111, 197, 456')",
    "print('Neyman allocation: 9, 48, 142, 604')",
    sep = "\n"
  )
  fixture_python_output <- paste(
    "Proportional allocation: 39, 111, 197, 456",
    "Neyman allocation: 9, 48, 142, 604",
    sep = "\n"
  )
  python_tool_answer <- paste(
    "[fixture] The Python interpreter tool returned the same allocation totals as the R tool.",
    fixture_python_output,
    sep = "\n"
  )
  python_live <- list(
    answer = python_tool_answer,
    tool_called = TRUE,
    model = "fixture",
    trace = list(
      chat_trace = "[fixture] Simulated ellmer tool call for run_python.",
      usage = list(prompt_tokens = NA_integer_, completion_tokens = NA_integer_),
      tool_calls = list(list(
        name = "run_python",
        arguments = list(code = fixture_python_code),
        result = list(
          code = fixture_python_code,
          exit_status = 0L,
          output = fixture_python_output
        )
      ))
    )
  )
  python_tool_called <- python_live$tool_called
} else {
  no_tool_response <- ellmer_openrouter_chat(
    prompt = sampling_prompt,
    system_prompt = "Answer directly without calling external tools. This is intentionally the no-tool baseline.",
    temperature = 0,
    max_tokens = 450,
    paths = paths
  )
  no_tool_answer <- no_tool_response$content

  live <- run_live_tool_call(total_n)
  tool_answer <- live$answer
  tool_called <- live$tool_called

  python_live <- run_live_python_tool_call(total_n)
  python_tool_answer <- python_live$answer
  python_tool_called <- python_live$tool_called
}

python_tool_result <- if (length(python_live$trace$tool_calls)) {
  python_live$trace$tool_calls[[1]]$result
} else {
  list()
}

# Pull out the code the model wrote and the stdout R captured when it executed
# that code locally. These are the two things the demo is meant to make visible,
# so they get their own sections in the markdown trace below.
python_code_text <- python_tool_result$code %||% "(no run_python tool call was captured)"
python_output_text <- python_tool_result$output %||% "(no tool output was captured)"

trace <- list(
  fixed_function_tool = live$trace,
  python_interpreter_tool = python_live$trace
)

answer_comparison <- data.frame(
  approach = c("no_tool", "fixed_function_tool", "python_interpreter_tool"),
  tool_called = c(FALSE, tool_called, python_tool_called),
  client = c(no_tool_response$client, "ellmer_openrouter", "ellmer_openrouter"),
  model = c(no_tool_response$model, live$model %||% NA_character_, python_live$model %||% NA_character_),
  executed_code = c(NA_character_, NA_character_, python_tool_result$code %||% NA_character_),
  tool_output = c(NA_character_, NA_character_, python_tool_result$output %||% NA_character_),
  answer = c(no_tool_answer, tool_answer, python_tool_answer),
  stringsAsFactors = FALSE
)
write_csv_file(answer_comparison, file.path(paths$outputs, "sampling_tool_answer_comparison.csv"))

# ------------------------------------------------------------------------------
# 6. Host-side validation
# ------------------------------------------------------------------------------
#
# This is the research-grade enforcement step. We do not merely ask the model to
# use a tool; we check whether the trace actually contains a tool call and whether
# the returned allocations sum to the requested total.

validation <- data.frame(
  check = c(
    "fixed_function_tool_called",
    "python_tool_called",
    "python_tool_exit_status_zero",
    "prop_total_equals_n",
    "neyman_total_equals_n"
  ),
  passed = c(
    tool_called,
    python_tool_called,
    identical(as.integer(python_tool_result$exit_status %||% NA_integer_), 0L),
    sum(allocation$prop_alloc) == total_n,
    sum(allocation$neyman_alloc) == total_n
  ),
  stringsAsFactors = FALSE
)
write_csv_file(validation, file.path(paths$outputs, "sampling_tool_validation.csv"))
write_json_file(trace, file.path(paths$outputs, "sampling_tool_trace.json"))

# ------------------------------------------------------------------------------
# 7. Markdown trace
# ------------------------------------------------------------------------------
#
# Open this file to inspect the question, R function, returned table, final model
# explanation, and validation checks.

trace_md <- c(
  "# Sampling Tool Trace",
  "",
  paste0("Mode: ", if (fixtures) "fixtures" else "live OpenRouter tool call via ellmer"),
  "",
  "## User Question",
  "",
  sampling_prompt,
  "",
  "## Stage 1: Without Tool",
  "",
  no_tool_answer,
  "",
  "## Stage 2: Registered R Tool",
  "",
  "```r",
  "sampling_allocation <- function(total_n = 800) {",
  "  prop_raw <- total_n * strata$N / sum(strata$N)",
  "  neyman_raw <- total_n * strata$N * strata$sd / sum(strata$N * strata$sd)",
  "  data.frame(stratum, prop_alloc, neyman_alloc)",
  "}",
  "```",
  "",
  "## Tool Result",
  "",
  paste(capture.output(print(allocation, row.names = FALSE)), collapse = "\n"),
  "",
  "## Tool-Grounded Answer",
  "",
  tool_answer,
  "",
  "## Python Interpreter Tool: Code the Model Generated",
  "",
  "The model wrote the Python below. R executed it locally via",
  "`system2(python3, ...)` and fed the captured stdout back to the model before",
  "it wrote its final answer. This is the step that was previously invisible.",
  "",
  "```python",
  python_code_text,
  "```",
  "",
  "## Python Interpreter Tool: Captured Output (run on this machine)",
  "",
  "```text",
  python_output_text,
  "```",
  "",
  "## Python Interpreter Tool: Final Answer",
  "",
  python_tool_answer,
  "",
  "## Answer Comparison",
  "",
  paste(capture.output(print(answer_comparison[, c("approach", "tool_called", "answer")], row.names = FALSE)), collapse = "\n"),
  "",
  "## Host-Side Validation",
  "",
  paste(capture.output(print(validation, row.names = FALSE)), collapse = "\n"),
  "",
  "## Tool Claim",
  "",
  "The LLM chooses the method and explains the result; the tool performs the calculation."
)
writeLines(trace_md, file.path(paths$outputs, "sampling_tool_trace.md"))

cat("Wrote sampling tool outputs to ", paths$outputs, "\n", sep = "")
print(validation, row.names = FALSE)
