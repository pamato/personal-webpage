# Workshop 2 R Demo Code

Run all deterministic demo checks from the repository root:

```sh
Rscript --vanilla "workshop 2/R/00_validate_all.R"
```

The validator runs every fixture-capable demo in fixture mode, regenerates outputs under `workshop 2/outputs/`, and checks the expected evidence. The validator is intentionally no-network/no-credit; it is not the live teaching path. `04_openalex_mcp_demo.R` is excluded because it is deliberately live-only.

## Live OpenRouter Runs

Live API/tool calls are now the default for the demo scripts. This also works when you run the scripts chunk by chunk in RStudio, because `fixtures` is `FALSE` unless you explicitly set `--fixtures`.

```sh
Rscript --vanilla "workshop 2/R/02_anes_prompt_demos.R"
Rscript --vanilla "workshop 2/R/03_questionnaire_rag.R"
Rscript --vanilla "workshop 2/R/04_openalex_mcp_demo.R"
Rscript --vanilla "workshop 2/R/05_sampling_tool_demo.R"
```

The helper loads `.env` from the repository root and from `workshop 2/.env`. It recognises `OPENROUTER_API_KEY`, `OPENROUTER_KEY`, `key`, `OPENAI_API_KEY`, or `API_KEY`; generic key names are mapped internally to `OPENROUTER_API_KEY`. Override the live model with `OPENROUTER_MODEL`; otherwise the scripts default to `openai/gpt-4.1-mini`.

For no-network rehearsal, add `--fixtures`:

```sh
Rscript --vanilla "workshop 2/R/02_anes_prompt_demos.R" --fixtures
```

Do not pass `--fixtures` to `04_openalex_mcp_demo.R`; that script is a live-only OpenRouter/OpenAlex demo and will stop with an explanatory error.

## Scripts

- `01_prepare_anes_data.R`: extracts the small labelled ANES Republican-likes demo set from `ABJK_Declarations.RData`.
- `02_anes_prompt_demos.R`: ordinary chat vs structured output, generation parameters, prompt stability, prompt-variant scoring, and structured evaluation metadata.
- `03_questionnaire_rag.R`: naive, markdown-like, and question-block retrieval over the Understanding Society Wave 17 questionnaire PDF.
- `04_openalex_mcp_demo.R`: live no-tool vs OpenAlex-tool literature search and suspicious-citation verification. The script acknowledges the public `drAbreu/alex-mcp` server while using direct live OpenAlex API calls so the R host-side tool boundary remains visible. It also writes an ellmer + mcptools wiring section showing how `ellmer::chat_openrouter()` can use tools from an MCP server via `mcptools::mcp_tools()` and `$set_tools()`.
- `05_sampling_tool_demo.R`: model-vs-calculator sampling allocation demo with host-side validation.
- `00_validate_all.R`: fixture-mode end-to-end validation.

## Core Packages

The code uses installed R packages `httr2` and `jsonlite` for live API calls and JSON handling. It uses base R plus installed tidyverse-compatible CSV/data-frame handling for fixture validation. PDF extraction uses `pdftotext` when `pdftools` is not installed.

`ellmer`, `vitals`, and `mcptools` are installed in this R environment and are used for the higher-level LLM/tooling demonstrations. `ragnar`, `duckdb`, and `pdftools` are useful workshop packages for retrieval workflows; the current RAG script still keeps runnable fallbacks for environments where those are absent.
