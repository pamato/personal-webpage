`%||%` <- function(x, y) {
  if (is.null(x) || length(x) == 0) y else x
}

current_script_path <- function(default = NULL) {
  args <- commandArgs(FALSE)
  file_arg <- grep("^--file=", args, value = TRUE)
  if (length(file_arg)) {
    path <- gsub("~\\+~", " ", sub("^--file=", "", file_arg[[1]]))
    return(normalizePath(path, mustWork = FALSE))
  }
  default
}

workshop_paths <- function(script_path = current_script_path()) {
  if (is.null(script_path) || is.na(script_path)) {
    cwd <- normalizePath(getwd(), mustWork = TRUE)
    candidates <- unique(c(
      if (basename(cwd) == "R") file.path(cwd, "..") else character(),
      if (basename(cwd) == "workshop 2") cwd else character(),
      file.path(cwd, "workshop 2"),
      file.path(dirname(cwd), "workshop 2")
    ))
    candidates <- candidates[dir.exists(file.path(candidates, "R")) & dir.exists(file.path(candidates, "data"))]
    if (!length(candidates)) {
      stop(
        "Could not locate the workshop root. Run from the repository root, `workshop 2`, or `workshop 2/R`, ",
        "or call workshop_paths(script_path = '<path to a script in workshop 2/R>').",
        call. = FALSE
      )
    }
    root <- normalizePath(candidates[[1]], mustWork = TRUE)
  } else {
    root <- normalizePath(file.path(dirname(script_path), ".."), mustWork = TRUE)
  }
  list(
    root = root,
    r = file.path(root, "R"),
    data = file.path(root, "data"),
    outputs = file.path(root, "outputs"),
    fixtures = file.path(root, "fixtures")
  )
}

ensure_demo_dirs <- function(paths = workshop_paths()) {
  dir.create(paths$outputs, recursive = TRUE, showWarnings = FALSE)
  dir.create(paths$fixtures, recursive = TRUE, showWarnings = FALSE)
  dir.create(file.path(paths$outputs, "rag"), recursive = TRUE, showWarnings = FALSE)
  dir.create(file.path(paths$outputs, "pdf_text"), recursive = TRUE, showWarnings = FALSE)
  invisible(paths)
}

trim_ws <- function(x) {
  gsub("^\\s+|\\s+$", "", x)
}

collapse_ws <- function(x) {
  trim_ws(gsub("\\s+", " ", x))
}

write_csv_file <- function(x, path) {
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  utils::write.csv(x, path, row.names = FALSE, na = "")
  invisible(path)
}

read_csv_file <- function(path, ...) {
  utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE, ...)
}

write_json_file <- function(x, path, pretty = TRUE, auto_unbox = TRUE) {
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    stop("The jsonlite package is required for JSON output.", call. = FALSE)
  }
  dir.create(dirname(path), recursive = TRUE, showWarnings = FALSE)
  jsonlite::write_json(x, path, pretty = pretty, auto_unbox = auto_unbox, null = "null")
  invisible(path)
}

load_env_file <- function(path) {
  if (!file.exists(path)) {
    return(invisible(character()))
  }
  lines <- readLines(path, warn = FALSE)
  lines <- trim_ws(lines)
  lines <- lines[nzchar(lines) & !grepl("^#", lines)]
  keys <- character()
  for (line in lines) {
    if (!grepl("=", line, fixed = TRUE)) next
    key <- trim_ws(sub("=.*$", "", line))
    value <- trim_ws(sub("^[^=]*=", "", line))
    value <- sub('^"(.*)"$', "\\1", value)
    value <- sub("^'(.*)'$", "\\1", value)
    if (nzchar(key) && !nzchar(Sys.getenv(key))) {
      do.call(Sys.setenv, stats::setNames(list(value), key))
    }
    keys <- c(keys, key)
  }
  invisible(keys)
}

load_openrouter_env <- function(paths = workshop_paths()) {
  repo_env <- file.path(dirname(paths$root), ".env")
  workshop_env <- file.path(paths$root, ".env")
  load_env_file(repo_env)
  load_env_file(workshop_env)

  if (!nzchar(Sys.getenv("OPENROUTER_API_KEY"))) {
    for (candidate in c("OPENROUTER_KEY", "key", "OPENAI_API_KEY", "API_KEY")) {
      value <- Sys.getenv(candidate)
      if (nzchar(value)) {
        Sys.setenv(OPENROUTER_API_KEY = value)
        break
      }
    }
  }

  if (!nzchar(Sys.getenv("OPENROUTER_MODEL"))) {
    Sys.setenv(OPENROUTER_MODEL = "openai/gpt-4.1-mini")
  }
  invisible(TRUE)
}

require_openrouter <- function(paths = workshop_paths()) {
  load_openrouter_env(paths)
  if (!requireNamespace("httr2", quietly = TRUE)) {
    stop("Install httr2 for live OpenRouter calls, or run with --fixtures.", call. = FALSE)
  }
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    stop("Install jsonlite for live OpenRouter calls, or run with --fixtures.", call. = FALSE)
  }
  key <- Sys.getenv("OPENROUTER_API_KEY")
  if (!nzchar(key)) {
    stop("No OpenRouter API key found. Set OPENROUTER_API_KEY, OPENROUTER_KEY, key, or API_KEY in .env, or run with --fixtures.", call. = FALSE)
  }
  invisible(key)
}

require_ellmer_openrouter <- function(paths = workshop_paths()) {
  key <- require_openrouter(paths)
  if (!requireNamespace("ellmer", quietly = TRUE)) {
    stop("Install ellmer for live OpenRouter calls, or run with --fixtures.", call. = FALSE)
  }
  if (is.null(getOption("ellmer_timeout_s"))) {
    options(ellmer_timeout_s = 45)
  }
  if (is.null(getOption("ellmer_max_tries"))) {
    options(ellmer_max_tries = 2)
  }
  invisible(key)
}

ellmer_openrouter_session <- function(system_prompt = "You are a careful research assistant.",
                                      model = Sys.getenv("OPENROUTER_MODEL", "openai/gpt-4.1-mini"),
                                      temperature = 0,
                                      seed = NULL,
                                      max_tokens = 300,
                                      api_args = list(),
                                      paths = workshop_paths()) {
  key <- require_ellmer_openrouter(paths)
  param_args <- list(
    temperature = temperature,
    max_tokens = max(as.integer(max_tokens), 16L)
  )
  if (!is.null(seed) && !is.na(seed)) {
    param_args$seed <- seed
  }
  ellmer::chat_openrouter(
    system_prompt = system_prompt,
    credentials = function() key,
    model = model,
    params = do.call(ellmer::params, param_args),
    api_args = api_args,
    api_headers = c(
      `HTTP-Referer` = "https://local.ncrm-workshop.invalid",
      `X-Title` = "NCRM LLM Workshop 2"
    ),
    echo = "none"
  )
}

ellmer_usage <- function(chat) {
  tokens <- tryCatch(chat$get_tokens(), error = function(e) NULL)
  if (is.null(tokens) || !is.data.frame(tokens) || !nrow(tokens)) {
    return(list(prompt_tokens = NA_integer_, completion_tokens = NA_integer_))
  }
  list(
    prompt_tokens = as.integer(sum(tokens$input %||% 0, na.rm = TRUE)),
    completion_tokens = as.integer(sum(tokens$output %||% 0, na.rm = TRUE))
  )
}

ellmer_trace_text <- function(chat) {
  paste(capture.output(print(chat)), collapse = "\n")
}

ellmer_openrouter_chat <- function(prompt,
                                   system_prompt = "You are a careful research assistant.",
                                   model = Sys.getenv("OPENROUTER_MODEL", "openai/gpt-4.1-mini"),
                                   temperature = 0,
                                   seed = NULL,
                                   max_tokens = 300,
                                   api_args = list(),
                                   paths = workshop_paths()) {
  chat <- ellmer_openrouter_session(
    system_prompt = system_prompt,
    model = model,
    temperature = temperature,
    seed = seed,
    max_tokens = max_tokens,
    api_args = api_args,
    paths = paths
  )
  content <- as.character(chat$chat(prompt, echo = "none"))
  list(
    content = content,
    message = list(content = content),
    raw = list(trace = ellmer_trace_text(chat)),
    usage = ellmer_usage(chat),
    model = chat$get_model(),
    client = "ellmer_openrouter",
    chat = chat
  )
}

ellmer_structured_chat <- function(prompt,
                                   type,
                                   system_prompt = "You are a careful research assistant.",
                                   model = Sys.getenv("OPENROUTER_MODEL", "openai/gpt-4.1-mini"),
                                   temperature = 0,
                                   seed = NULL,
                                   max_tokens = 300,
                                   paths = workshop_paths()) {
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    stop("jsonlite is required to serialize structured ellmer output.", call. = FALSE)
  }
  chat <- ellmer_openrouter_session(
    system_prompt = system_prompt,
    model = model,
    temperature = temperature,
    seed = seed,
    max_tokens = max_tokens,
    paths = paths
  )
  value <- chat$chat_structured(prompt, type = type, echo = "none")
  content <- as.character(jsonlite::toJSON(value, auto_unbox = TRUE, null = "null"))
  list(
    content = content,
    structured = value,
    message = list(content = content),
    raw = list(trace = ellmer_trace_text(chat)),
    usage = ellmer_usage(chat),
    model = chat$get_model(),
    client = "ellmer_openrouter",
    chat = chat
  )
}

ellmer_classification_type <- function() {
  ellmer::type_object(
    category_id = ellmer::type_integer("Category ID from 1 to 5."),
    mixed_valence = ellmer::type_boolean("Whether the response also states a dislike or reservation."),
    confidence = ellmer::type_number("Confidence from 0 to 1."),
    evidence = ellmer::type_string("Short text evidence for the coding decision.")
  )
}

openrouter_chat <- function(prompt,
                            system_prompt = "You are a careful research assistant.",
                            model = Sys.getenv("OPENROUTER_MODEL", "openai/gpt-4.1-mini"),
                            temperature = 0,
                            seed = NULL,
                            max_tokens = 300,
                            response_format = NULL,
                            tools = NULL,
                            tool_choice = NULL,
                            messages = NULL,
                            paths = workshop_paths()) {
  key <- require_openrouter(paths)
  if (is.null(messages)) {
    messages <- list(
      list(role = "system", content = system_prompt),
      list(role = "user", content = prompt)
    )
  }
  max_tokens <- max(as.integer(max_tokens), 16L)
  body <- list(
    model = model,
    messages = messages,
    temperature = temperature,
    max_tokens = max_tokens
  )
  if (!is.null(seed)) body$seed <- seed
  if (!is.null(response_format)) body$response_format <- response_format
  if (!is.null(tools)) body$tools <- tools
  if (!is.null(tool_choice)) body$tool_choice <- tool_choice

  response <- httr2::request("https://openrouter.ai/api/v1/chat/completions") |>
    httr2::req_headers(
      Authorization = paste("Bearer", key),
      `Content-Type` = "application/json",
      `HTTP-Referer` = "https://local.ncrm-workshop.invalid",
      `X-Title` = "NCRM LLM Workshop 2"
    ) |>
    httr2::req_body_json(body, auto_unbox = TRUE) |>
    httr2::req_perform()

  parsed <- httr2::resp_body_json(response, simplifyVector = FALSE)
  choice <- parsed$choices[[1]] %||% list(message = list(content = ""))
  list(
    content = choice$message$content %||% "",
    message = choice$message %||% list(),
    raw = parsed,
    usage = parsed$usage %||% list(),
    model = parsed$model %||% model
  )
}

json_schema_response_format <- function(name, schema, strict = TRUE) {
  list(
    type = "json_schema",
    json_schema = list(
      name = name,
      strict = strict,
      schema = schema
    )
  )
}

strip_code_fences <- function(x) {
  x <- trim_ws(x)
  x <- sub("^```[A-Za-z0-9_-]*\\s*", "", x)
  x <- sub("\\s*```$", "", x)
  trim_ws(x)
}

extract_first_json_object <- function(x) {
  x <- strip_code_fences(x)
  chars <- strsplit(x, "", fixed = TRUE)[[1]]
  start <- which(chars == "{")[1]
  if (is.na(start)) return(x)
  depth <- 0
  in_string <- FALSE
  escaped <- FALSE
  for (i in seq.int(start, length(chars))) {
    ch <- chars[[i]]
    if (escaped) {
      escaped <- FALSE
    } else if (ch == "\\\\") {
      escaped <- TRUE
    } else if (ch == "\"") {
      in_string <- !in_string
    } else if (!in_string && ch == "{") {
      depth <- depth + 1
    } else if (!in_string && ch == "}") {
      depth <- depth - 1
      if (depth == 0) {
        return(paste(chars[start:i], collapse = ""))
      }
    }
  }
  x
}

parse_json_object <- function(x) {
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    stop("jsonlite is required to parse structured output.", call. = FALSE)
  }
  candidate <- extract_first_json_object(x)
  tryCatch(
    jsonlite::fromJSON(candidate, simplifyVector = FALSE),
    error = function(e) list(.parse_error = conditionMessage(e), .raw = x)
  )
}

category_codebook <- function() {
  data.frame(
    category_id = 1:5,
    label = c("Economic", "Defense", "Social/Moral", "Party Image/Loyalty", "Social Welfare"),
    definition = c(
      "Small government, deregulation, cutting spending, taxes, individual enterprise, fiscal responsibility.",
      "Military strength, foreign policy, strong national defense.",
      "Traditional values, abortion, school prayer, religious values.",
      "Generalized party praise, running a tight ship, group identification, lifelong loyalty.",
      "Complex views on welfare, helping the lower class, or disability benefits."
    ),
    stringsAsFactors = FALSE
  )
}

codebook_text <- function() {
  cb <- category_codebook()
  paste(sprintf(
    "ID %s (%s): %s",
    cb$category_id,
    cb$label,
    cb$definition
  ), collapse = "\n")
}

keyword_scores <- function(text, keyword_map) {
  txt <- tolower(text)
  vapply(keyword_map, function(words) {
    sum(vapply(words, function(word) grepl(word, txt, fixed = TRUE), logical(1)))
  }, numeric(1))
}

heuristic_classify_replikes <- function(text, prompt_variant = "structured", run = 1, temperature = 0) {
  first_sentence <- strsplit(text, "(?<=[.!?])\\s+", perl = TRUE)[[1]][1]
  keywords <- list(
    Economic = c("budget", "fiscal", "spending", "tax", "taxes", "deregulation", "private", "enterprise", "econom"),
    Defense = c("defense", "foreign", "military", "weak", "strength"),
    `Social/Moral` = c("moral", "abortion", "prayer", "religious", "values", "traditional"),
    `Party Image/Loyalty` = c("organization", "tight ship", "solid party", "identified", "identification", "successful people", "conservative person"),
    `Social Welfare` = c("welfare", "disability", "disabled", "handicapped", "less fortunate", "lower class")
  )
  first_scores <- keyword_scores(first_sentence, keywords)
  full_scores <- keyword_scores(text, keywords)
  scores <- if (max(first_scores) > 0) first_scores * 2 + full_scores else full_scores
  label <- names(which.max(scores))
  if (max(scores) == 0) label <- "Party Image/Loyalty"

  id <- match(label, category_codebook()$label)
  mixed <- grepl("on the other hand|however|although|but |dislike|takes away|cut my disability", text, ignore.case = TRUE)

  if (temperature > 0.7 && prompt_variant %in% c("bad_default", "prompt_v1")) {
    if ((nchar(text) + run) %% 5 == 0) {
      id <- c(4, 1, 3, 4, 5)[id]
      label <- category_codebook()$label[[id]]
    }
  }

  list(
    category_id = as.integer(id),
    category_label = label,
    mixed_valence = isTRUE(mixed),
    confidence = if (max(scores) >= 4) 0.88 else if (max(scores) >= 2) 0.74 else 0.55,
    evidence = substr(collapse_ws(first_sentence), 1, 120)
  )
}

format_default_fixture_output <- function(classification) {
  sprintf(
    "The best fit is probably %s (ID %s). I would use this because the response contains evidence such as: %s.",
    classification$category_label,
    classification$category_id,
    classification$evidence
  )
}

format_structured_fixture_output <- function(classification) {
  if (!requireNamespace("jsonlite", quietly = TRUE)) {
    stop("jsonlite is required for structured fixture output.", call. = FALSE)
  }
  jsonlite::toJSON(
    list(
      category_id = classification$category_id,
      mixed_valence = classification$mixed_valence,
      confidence = classification$confidence,
      evidence = classification$evidence
    ),
    auto_unbox = TRUE
  )
}

classification_schema <- function() {
  list(
    type = "object",
    additionalProperties = FALSE,
    required = c("category_id", "mixed_valence", "confidence", "evidence"),
    properties = list(
      category_id = list(type = "integer", enum = as.list(1:5)),
      mixed_valence = list(type = "boolean"),
      confidence = list(type = "number", minimum = 0, maximum = 1),
      evidence = list(type = "string")
    )
  )
}

tokenize_text <- function(x) {
  x <- tolower(gsub("[^A-Za-z0-9_]+", " ", x))
  terms <- unlist(strsplit(x, "\\s+"))
  stopwords <- c("the", "and", "for", "that", "with", "this", "from", "are", "was", "were", "has", "have", "who", "what", "which", "does", "into", "about", "question", "variable")
  terms[nzchar(terms) & nchar(terms) > 2 & !(terms %in% stopwords)]
}

make_fixed_chunks <- function(text, chunk_size = 1000, overlap = 150, prefix = "naive") {
  n <- nchar(text)
  if (n == 0) return(data.frame())
  step <- max(1, chunk_size - overlap)
  starts <- seq(1, n, by = step)
  data.frame(
    chunk_id = sprintf("%s_%04d", prefix, seq_along(starts)),
    chunk_type = prefix,
    context = NA_character_,
    source_page = NA_integer_,
    text = vapply(starts, function(start) substr(text, start, min(n, start + chunk_size - 1)), character(1)),
    stringsAsFactors = FALSE
  )
}

score_retrieval <- function(query, texts) {
  q_terms <- unique(tokenize_text(query))
  if (!length(q_terms)) {
    return(data.frame(bm25 = rep(0, length(texts)), cosine_distance = rep(1, length(texts))))
  }
  q_vec <- table(factor(q_terms, levels = q_terms))
  bm25 <- numeric(length(texts))
  cosine <- numeric(length(texts))
  for (i in seq_along(texts)) {
    terms <- tokenize_text(texts[[i]])
    if (!length(terms)) {
      bm25[[i]] <- 0
      cosine[[i]] <- 0
      next
    }
    counts <- table(factor(terms, levels = q_terms))
    exact_boost <- sum(vapply(q_terms, function(term) grepl(term, tolower(texts[[i]]), fixed = TRUE), logical(1))) * 0.25
    bm25[[i]] <- sum(log1p(as.numeric(counts))) + exact_boost
    denom <- sqrt(sum(as.numeric(q_vec)^2)) * sqrt(sum(as.numeric(counts)^2))
    cosine[[i]] <- if (denom == 0) 0 else sum(as.numeric(q_vec) * as.numeric(counts)) / denom
  }
  data.frame(bm25 = bm25, cosine_distance = 1 - cosine, stringsAsFactors = FALSE)
}

retrieve_chunks <- function(chunks, query, top_k = 3, strategy = c("hybrid", "bm25", "vss")) {
  strategy <- match.arg(strategy)
  scores <- score_retrieval(query, chunks$text)
  out <- cbind(chunks, scores)
  max_bm25 <- max(out$bm25, na.rm = TRUE)
  norm_bm25 <- if (max_bm25 > 0) out$bm25 / max_bm25 else out$bm25
  norm_vss <- 1 - out$cosine_distance
  out$hybrid_score <- 0.55 * norm_bm25 + 0.45 * norm_vss
  order_col <- switch(strategy, bm25 = out$bm25, vss = -out$cosine_distance, hybrid = out$hybrid_score)
  out <- out[order(-order_col, out$chunk_id), , drop = FALSE]
  utils::head(out, top_k)
}

extract_pdf_text <- function(pdf_path, out_txt) {
  dir.create(dirname(out_txt), recursive = TRUE, showWarnings = FALSE)
  if (file.exists(out_txt) && file.info(out_txt)$size > 0) {
    return(out_txt)
  }
  if (requireNamespace("pdftools", quietly = TRUE)) {
    pages <- pdftools::pdf_text(pdf_path)
    writeLines(paste(pages, collapse = "\f"), out_txt, useBytes = TRUE)
    return(out_txt)
  }
  pdftotext <- Sys.which("pdftotext")
  if (!nzchar(pdftotext)) {
    stop("Need pdftools or the pdftotext command-line utility to extract the questionnaire PDF.", call. = FALSE)
  }
  status <- system2(pdftotext, c("-layout", shQuote(pdf_path), shQuote(out_txt)), stdout = TRUE, stderr = TRUE)
  if (!file.exists(out_txt) || file.info(out_txt)$size == 0) {
    stop("PDF text extraction failed: ", paste(status, collapse = "\n"), call. = FALSE)
  }
  out_txt
}

read_text_file_raw <- function(path) {
  paste(readLines(path, warn = FALSE, encoding = "UTF-8"), collapse = "\n")
}

read_pdf_pages <- function(txt_path) {
  size <- file.info(txt_path)$size
  text <- readChar(txt_path, nchars = size, useBytes = TRUE)
  strsplit(text, "\f", fixed = TRUE)[[1]]
}

extract_section <- function(block, start_label, end_labels) {
  escape_regex <- function(x) gsub("([][{}()+*^$.|?\\\\])", "\\\\\\1", x, perl = TRUE)
  start_pattern <- paste0("(?m)^\\s*", escape_regex(start_label))
  start <- regexpr(start_pattern, block, perl = TRUE)
  if (start[[1]] < 0) return(NA_character_)
  after <- start[[1]] + attr(start, "match.length")
  tail <- substr(block, after, nchar(block))
  end_patterns <- paste0("(?m)^\\s*", escape_regex(end_labels))
  ends <- vapply(end_patterns, function(p) {
    m <- regexpr(p, tail, perl = TRUE)[[1]]
    if (m < 0) Inf else m
  }, numeric(1))
  end <- min(ends)
  section <- if (is.infinite(end)) tail else substr(tail, 1, end - 1)
  collapse_ws(section)
}

extract_line_value <- function(block, label) {
  pattern <- paste0("(?m)^\\s*", label, "\\s*(.*)$")
  m <- regexpr(pattern, block, perl = TRUE)
  if (m[[1]] < 0) return(NA_character_)
  value <- regmatches(block, m)
  value <- sub(paste0("^\\s*", label, "\\s*"), "", value)
  collapse_ws(value)
}

parse_question_blocks <- function(pages) {
  rows <- list()
  idx <- 1
  for (page in seq_along(pages)) {
    text <- pages[[page]]
    starts <- gregexpr("(?m)^\\s*Question:\\s+[A-Za-z0-9_]+\\.[A-Za-z0-9_]+", text, perl = TRUE)[[1]]
    if (starts[[1]] < 0) next
    starts <- as.integer(starts)
    ends <- c(starts[-1] - 1L, nchar(text))
    for (j in seq_along(starts)) {
      block <- substr(text, starts[[j]], ends[[j]])
      q_line <- regmatches(block, regexpr("(?m)^\\s*Question:\\s+[A-Za-z0-9_]+\\.[A-Za-z0-9_]+.*$", block, perl = TRUE))
      qid <- sub(".*Question:\\s+([A-Za-z0-9_]+\\.[A-Za-z0-9_]+).*", "\\1", q_line)
      variable <- sub("^.*\\.", "", qid)
      module <- extract_line_value(block, "Module:")
      module_group <- sub("_w[0-9]+.*$", "", module)
      universe <- extract_section(block, "Universe:", c("Text:", "Options:", "Help:", "Mixed Mode", "Use:", "Question:", "Hard Check:", "Soft Check:"))
      question_text <- extract_section(block, "Text:", c("Options:", "Help:", "Mixed Mode", "Use:", "Question:", "Post-text", "Interviewer", "Instruction:", "Hard Check:", "Soft Check:"))
      response_options <- extract_section(block, "Options:", c("Help:", "Mixed Mode", "Use:", "Question:", "Notes:", "Interviewer", "Hard Check:", "Soft Check:"))
      lookback <- substr(text, max(1, starts[[j]] - 600), starts[[j]] - 1)
      if_lines <- grep("^\\s*if\\s*[\\[(]", strsplit(lookback, "\n", fixed = TRUE)[[1]], value = TRUE)
      routing_before <- if (length(if_lines)) collapse_ws(tail(if_lines, 1)) else NA_character_
      rows[[idx]] <- data.frame(
        chunk_id = sprintf("question_%04d", idx),
        chunk_type = "question_block",
        wave = "wave_17",
        module = module,
        module_group = module_group,
        respondent_type = "adult",
        question_id = qid,
        variable_name = variable,
        universe = universe,
        routing_before = routing_before,
        question_text = question_text,
        response_options = response_options,
        source_page = page,
        text = collapse_ws(paste(
          "wave: wave_17",
          paste0("module: ", module),
          paste0("question_id: ", qid),
          paste0("variable_name: ", variable),
          paste0("question_text: ", question_text),
          paste0("universe: ", universe),
          paste0("routing_before: ", routing_before),
          paste0("response_options: ", response_options),
          paste0("source_page: ", page),
          sep = "\n"
        )),
        stringsAsFactors = FALSE
      )
      idx <- idx + 1
    }
  }
  if (!length(rows)) return(data.frame())
  do.call(rbind, rows)
}

make_markdown_like_chunks <- function(question_blocks) {
  if (!nrow(question_blocks)) return(data.frame())
  data.frame(
    chunk_id = sprintf("markdown_%04d", seq_len(nrow(question_blocks))),
    chunk_type = "markdown_like",
    context = paste(question_blocks$module, question_blocks$question_id, sep = " / "),
    source_page = question_blocks$source_page,
    text = paste0(
      "## ", question_blocks$module, "\n",
      "### ", question_blocks$question_id, "\n\n",
      "Universe: ", question_blocks$universe, "\n\n",
      "Question text: ", question_blocks$question_text, "\n\n",
      "Options: ", question_blocks$response_options
    ),
    stringsAsFactors = FALSE
  )
}

render_retrieval_markdown <- function(title, query, retrieved, answer = NULL) {
  lines <- c(
    paste0("# ", title),
    "",
    paste0("**Query:** ", query),
    "",
    "## Retrieved Chunks",
    ""
  )
  for (i in seq_len(nrow(retrieved))) {
    row <- retrieved[i, , drop = FALSE]
    lines <- c(
      lines,
      paste0("### ", row$chunk_id, " (", row$chunk_type, ")"),
      "",
      paste0("- `bm25`: ", round(row$bm25, 3)),
      paste0("- `cosine_distance`: ", round(row$cosine_distance, 3)),
      paste0("- `hybrid_score`: ", round(row$hybrid_score, 3)),
      if (!is.na(row$source_page)) paste0("- `source_page`: ", row$source_page) else character(),
      "",
      "```text",
      substr(row$text, 1, 2500),
      "```",
      ""
    )
  }
  if (!is.null(answer)) {
    lines <- c(lines, "## Teaching Answer", "", answer, "")
  }
  lines
}

script_args <- function() {
  commandArgs(trailingOnly = TRUE)
}

using_fixtures <- function(args = script_args()) {
  "--fixtures" %in% args || !"--live" %in% args
}
