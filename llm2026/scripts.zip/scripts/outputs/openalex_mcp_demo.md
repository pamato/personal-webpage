# OpenAlex MCP Literature Demo

Mode: live ellmer/OpenRouter + live OpenAlex

## MCP Server Note

An OpenAlex MCP server exists at https://github.com/drAbreu/alex-mcp.
For an MCP-capable client, a current direct-launch command is: `uvx --from git+https://github.com/drAbreu/alex-mcp.git@4.1.0 python -c 'from alex_mcp.server import mcp; mcp.run()'`.
This R script keeps the tool boundary visible by calling the live OpenAlex works API directly from the host program.

## Stage A: No Tool

This baseline uses `ellmer::chat_openrouter()`, not a hand-written OpenRouter request.

I don't have access to external databases or real-time information, so I can't provide recent papers or DOIs. However, I can suggest some example paper titles and authors based on my training data up to 2023 that are relevant to using large language models (LLMs) for survey response coding or text annotation:

1. Title: "Leveraging Large Language Models for Automated Survey Response Coding"  
   Authors: Jane Doe, John Smith  
   Year: 2023  
   DOI: 10.1234/example.doi1  
   Relevance: Demonstrates how LLMs can be fine-tuned to automatically code open-ended survey responses with high accuracy.

2. Title: "Text Annotation at Scale Using GPT-3: Applications in Social Science Research"  
   Authors: Alice Johnson, Mark Lee  
   Year: 2022  
   DOI: 10.1234/example.doi2  
   Relevance: Explores the use of GPT-3 for scalable and consistent text annotation in social science datasets.

3. Title: "Improving Qualitative Data Coding with Large Language Models"  
   Authors: Emily Zhang, Robert Brown  
   Year: 2023  
   DOI: 10.1234/example.doi3  
   Relevance: Investigates the effectiveness of LLMs in assisting qualitative researchers with coding and categorizing textual data.

If you need verified recent papers, I recommend searching academic databases like Google Scholar or Semantic Scholar directly.

## Stage B: Tool-Backed Search

Only return works actually found by the live OpenAlex title searches.

Live OpenAlex title queries: Do AIs know what the most important issue is | Coding Open-Ended Responses using Pseudo Response Generation | Navigating the Risks of Using Large Language Models for Text Annotation

                                                                                                                  title
 Do AIs know what the most important issue is? Using language models to code open-text social survey responses at scale
                                  Coding Open-Ended Responses using Pseudo Response Generation by Large Language Models
                     Navigating the Risks of Using Large Language Models for Text Annotation in Social Science Research
 year                                           doi
 2024     https://doi.org/10.1177/20531680241231468
 2024 https://doi.org/10.18653/v1/2024.naacl-srw.26
 2025     https://doi.org/10.1177/08944393251366243

## Stage C: Suspicious Citation Verification

                                                                           suspicious_title
 Prompt Stability Scoring for Text Annotation with Large Language Models in Survey Research
    status closest_tool_title                    evidence
 not_found               <NA> OpenAlex returned no works.

## Stage D: ellmer + MCP Client Wiring

This is the actual R-side bridge when you want the OpenRouter model to use tools from an MCP server. ellmer is the LLM client; mcptools is the MCP client. The MCP server does not become the model, and the model still does not call the OpenAlex REST API directly. The R host gives the model tool schemas, receives tool-call requests, and mcptools executes those requests against the MCP server.

Config template written to: /Users/pauloserodio/Documents/ISER/teaching/ncrm/llm2026/workshop 2/outputs/openalex_mcp_ellmer_config.json

```r
library(ellmer)
library(mcptools)

# The config points mcptools at the alex-mcp stdio server.
config <- "/Users/pauloserodio/Documents/ISER/teaching/ncrm/llm2026/workshop 2/outputs/openalex_mcp_ellmer_config.json"

chat <- ellmer::chat_openrouter(
  system_prompt = "Use OpenAlex MCP tools for literature evidence. Do not invent citations.",
  model = Sys.getenv("OPENROUTER_MODEL", "openai/gpt-4.1-mini"),
  echo = "none"
)

chat$set_tools(mcptools::mcp_tools(config = config))
chat$chat(
  "Use the OpenAlex tools to check whether this title exists: Prompt Stability Scoring for Text Annotation with Large Language Models in Survey Research"
)
```

Local live-run status:

          component available
             ellmer      TRUE
             vitals      TRUE
           mcptools      TRUE
                uvx      TRUE
    OPENALEX_MAILTO     FALSE
 OPENROUTER_API_KEY      TRUE
   live_mcp_attempt     FALSE
                                                  detail
                                 R package is installed.
                                 R package is installed.
                                 R package is installed.
                      /Users/pauloserodio/.local/bin/uvx
            Set OPENALEX_MAILTO before running alex-mcp.
                                     Set in environment.
 Not attempted; missing one or more local prerequisites.

Live ellmer + MCP answer or skip reason:

Live ellmer + MCP call was not attempted.
Missing prerequisite(s): OPENALEX_MAILTO.
Config template was written to: /Users/pauloserodio/Documents/ISER/teaching/ncrm/llm2026/workshop 2/outputs/openalex_mcp_ellmer_config.json
Install/configure the missing prerequisite(s), then rerun this script to make the live MCP call.

## Teaching Claim

MCP does not make the model more knowledgeable. It gives the host application a standardised way to expose external capabilities as tools. With ellmer + mcptools + OpenRouter, the host still mediates the call: OpenRouter receives tool schemas, the model requests a tool call, and R/mcptools executes that call through the MCP server.
