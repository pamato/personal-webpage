# ANES Prompt Outputs

Mode: live OpenRouter via ellmer

## Structured Output

Structured output turns a formatting request into an output contract. Here the same ANES coding task is run as ordinary chat and as JSON-constrained output.

## Ordinary Chat Requires Parsing

The ordinary-chat output is a text string. To turn it into the classification variable we need, the script has to run a post-processing parser. See `prompt_default_parsing_demo.csv` for raw output, parsing method, parser note, parsed category, and correctness.

## Prompt Optimisation Summary

 prompt_variant n correct accuracy
      prompt_v1 8       0    0.000
      prompt_v2 8       7    0.875
      prompt_v3 8       7    0.875

## vitals Prompt Optimisation Summary

 prompt_variant n correct accuracy
      prompt_v1 8       0    0.000
      prompt_v2 8       7    0.875
      prompt_v3 8       7    0.875

## Prompt Stability Summary

       id unique_predicted_categories
 RLIKE_01                           1
 RLIKE_04                           5
 RLIKE_05                           1
 RLIKE_06                           2
 RLIKE_07                           3

## Files

- `prompt_default_vs_structured.csv`
- `prompt_default_parsing_demo.csv`
- `prompt_parameter_runs.csv`
- `prompt_stability_runs.csv`
- `prompt_optimisation_predictions.csv`
- `prompt_optimisation_summary.csv`
- `prompt_vitals_optimisation_predictions.csv`
- `prompt_vitals_optimisation_summary.csv`
- `structured_evaluation_metadata.json`
