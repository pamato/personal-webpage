# RAG Retrieval economic_activity_vars markdown_like

**Query:** Which variables capture current economic activity, paid work last week, or whether the respondent has a job?

## Retrieved Chunks

### markdown_1175 (markdown_like)

- `bm25`: 10.459
- `cosine_distance`: 0.401
- `hybrid_score`: 0.819
- `source_page`: 736

```text
## annualemploymenthistory_w17
### annualemploymenthistory_w17.JBATT

Universe: if [ff_ivlolw = 1 | ff_everint = 1] // Interviewed at prior wave or has been interviewed previously And if [(EmpChk = 1 & ff_JBSTAT > 1 & ff_JBSTAT <> MIS|DK|REF) | (EMPCHK = 2 & ff_JBSTAT = 13 & NXTST = 1 & ff_JBSTAT <> MIS|DK|REF)] // Continuously employed since last interview OR Temp laid off status at last interview followed by paid work And if [Next = 1] // Has not reached current status And if [NextStat = 1] // Next employment status was paid employment And if [CurrJob = 1 & NextJob < 4] // Next employment status was current job

Question text: What was the main thing about your current job that attracted you to it?

Options: 1 Better money Better money 2 Better career prospects Better career prospects 3 More responsibility More responsibility 4 More secure job More secure job 5 More interesting work More interesting work 6 Wanted specific type of job Wanted specific type of job 7 To be own boss {if NEXTJOB =3} To be own boss {if NEXTJOB =3} 8 More opportunity to use own More opportunity to use own initiative initiative 9 Closer to home - less travelling time Closer to home - less travelling time to work to work 10 Shorter/fewer hours Shorter/fewer hours 11 More flexible hours More flexible hours 12 Health reasons Health reasons 13 Suited respondent's qualifications, Suited respondent's qualifications, training or experience training or experience 14 Work less demanding/easier Work less demanding/easier 15 Preferred to previous job Preferred to previous job 97 Other Other
```

### markdown_1864 (markdown_like)

- `bm25`: 8.762
- `cosine_distance`: 0.293
- `hybrid_score`: 0.779
- `source_page`: 1154

```text
## proxy_w17
### proxy_w17.PJBPTFT

Universe: if [GRIDVARIABLES.modetype = 1 | 2] // Mode is face-to-face or telephone And if [IProxy = 1] // Able to do a proxy interview for respondent And if [JBHAS = 1|JBOFF = 1] // Did paid work last week or no work last week but has a job And if [JBSEMP = 1] // Employee And if [JBHRS = DK] // Job hours not known

Question text: Would you say that [NAME] 's current job is part-time or full-time?

Options: 1 Part-time Part-time 2 Full-time Full-time Page 1152 of 1165
```

### markdown_1856 (markdown_like)

- `bm25`: 8.681
- `cosine_distance`: 0.344
- `hybrid_score`: 0.752
- `source_page`: 1150

```text
## proxy_w17
### proxy_w17.JBSOC00

Universe: if [GRIDVARIABLES.modetype = 1 | 2] // Mode is face-to-face or telephone And if [IProxy = 1] // Able to do a proxy interview for respondent And if [JBHAS = 1|JBOFF = 1] // Did paid work last week or no work last week but has a job

Question text: What was [NAME] 's (main) job last week? Please tell me the exact job title, if you can, and describe fully the sort of work they do.

Options: 
```

