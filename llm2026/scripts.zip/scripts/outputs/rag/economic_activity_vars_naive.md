# RAG Retrieval economic_activity_vars naive

**Query:** Which variables capture current economic activity, paid work last week, or whether the respondent has a job?

## Retrieved Chunks

### naive_3631 (naive)

- `bm25`: 10.882
- `cosine_distance`: 0.32
- `hybrid_score`: 0.843

```text
    2        No   No

       Help:        Include as looking for work: being registered at any government or private employment
                    agency, approaching employers, checking newspaper advertisements, making inquiries of
                    friends etc.
       Use:         Ask PJULK4WK



if [JBHAS = 1|JBOFF = 1] // Did paid work last week or no work last week but has a job




   Question: proxy_w17.JBTERM1                        [ Current job: permanent or temporary ]

    Module:        proxy_w17
    Source:        BHPS

                     Type: choice
                     Don't know: -1                 Refused: -2               Inapplicable: -8          Missing: -9

    Universe:      if [GRIDVARIABLES.modetype = 1 | 2] // Mode is face-to-face or telephone
                   And if [IProxy = 1] // Able to do a proxy interview for respondent
                   And if [JBHAS = 1|JBOFF = 1] // Did paid work last week or no work last week but has a job
    Text:         
```

### naive_2582 (naive)

- `bm25`: 11.143
- `cosine_distance`: 0.349
- `hybrid_score`: 0.843

```text
EMPLOYMENT.JBHAS = 1 | CURRENTEMPLOYMENT.JBOFF = 1] // did paid work last week or did no
paid work last week but has a job




   Question: workconditions_w17.WKTIME                     [ Times of day usually worked ]

   Module:       workconditions_w17
   Source:       BHPS
   Scripting     Text fills for Job Title and Firm should be filled with information for respondent's MAIN JOB where more
   Notes:        than one job is held.

                   Type: choice
                   Don't know: -1                 Refused: -2                   Inapplicable: -8            Missing: -9

   Universe:     if [CURRENTEMPLOYMENT.JBHAS = 1 | CURRENTEMPLOYMENT.JBOFF = 1] // did paid work last
                 week or did no paid work last week but has a job
   Showcard:     TBC
   Text:         Which times of day do you usually work in your job as a/an [TITLE] at [FIRM] {if MULTIJOBSTOTAL >
                 1 & ((ALLJOBSTITLE <> DK|REF|MIS) & (ALLJOBSFIRM <> DK|REF|MIS)) in your main job {if
 
```

### naive_3636 (naive)

- `bm25`: 10.253
- `cosine_distance`: 0.299
- `hybrid_score`: 0.822

```text
NECESSARY TO DISTINGUISH BETWEEN SOME
             OCCUPATIONS AT THE DETAILED LEVEL. DESCRIBE FULLY.
Help:         This should be the firm or company that issued the contract of employment for the respondent. If
              the respondent is self-employed, please describe what they mainly make or do.
Use:          Ask JBSIC07




Question: proxy_w17.JBSOC00                   [ Occupation (SOC2000): current job ]

Module:       proxy_w17
Source:       BHPS

               Type: String                   Length: 255
               Don't know: -1                Refused: -2                  Inapplicable: -8          Missing: -9

Universe:     if [GRIDVARIABLES.modetype = 1 | 2] // Mode is face-to-face or telephone
              And if [IProxy = 1] // Able to do a proxy interview for respondent
              And if [JBHAS = 1|JBOFF = 1] // Did paid work last week or no work last week but has a job
Text:         What was [NAME] 's (main) job last week? Please tell me the exact job title, i
```

