# RAG Retrieval economic_activity_vars question_block

**Query:** Which variables capture current economic activity, paid work last week, or whether the respondent has a job?

## Retrieved Chunks

### question_1175 (question_block)

- `bm25`: 10.787
- `cosine_distance`: 0.403
- `hybrid_score`: 0.819
- `source_page`: 736

```text
wave: wave_17 module: annualemploymenthistory_w17 question_id: annualemploymenthistory_w17.JBATT variable_name: JBATT question_text: What was the main thing about your current job that attracted you to it? universe: if [ff_ivlolw = 1 | ff_everint = 1] // Interviewed at prior wave or has been interviewed previously And if [(EmpChk = 1 & ff_JBSTAT > 1 & ff_JBSTAT <> MIS|DK|REF) | (EMPCHK = 2 & ff_JBSTAT = 13 & NXTST = 1 & ff_JBSTAT <> MIS|DK|REF)] // Continuously employed since last interview OR Temp laid off status at last interview followed by paid work And if [Next = 1] // Has not reached current status And if [NextStat = 1] // Next employment status was paid employment And if [CurrJob = 1 & NextJob < 4] // Next employment status was current job routing_before: if [CurrJob = 1 & NextJob < 4] // Next employment status was current job response_options: 1 Better money Better money 2 Better career prospects Better career prospects 3 More responsibility More responsibility 4 More secure job More secure job 5 More interesting work More interesting work 6 Wanted specific type of job Wanted specific type of job 7 To be own boss {if NEXTJOB =3} To be own boss {if NEXTJOB =3} 8 More opportunity to use own More opportunity to use own initiative initiative 9 Closer to home - less travelling time Closer to home - less travelling time to work to work 10 Shorter/fewer hours Shorter/fewer hours 11 More flexible hours More flexible hours 12 Health reasons Health reasons 13 Suited respondent's qualifications, Suited respondent's qualifications, training or experience training or experience 14 Work less demanding/easier Work less demanding/easier 15 Preferred to previous job Preferred to previous job 97 Other Other source_page: 736
```

### question_1853 (question_block)

- `bm25`: 10.162
- `cosine_distance`: 0.346
- `hybrid_score`: 0.812
- `source_page`: 1149

```text
wave: wave_17 module: proxy_w17 question_id: proxy_w17.JBTERM1 variable_name: JBTERM1 question_text: Leaving aside [NAME] 's own personal intentions and circumstances, is [NAME] 's job... universe: if [GRIDVARIABLES.modetype = 1 | 2] // Mode is face-to-face or telephone And if [IProxy = 1] // Able to do a proxy interview for respondent And if [JBHAS = 1|JBOFF = 1] // Did paid work last week or no work last week but has a job routing_before: if [JBHAS = 1|JBOFF = 1] // Did paid work last week or no work last week but has a job response_options: 1 A permanent job A permanent job 2 Or is there some way that it is not Or is there some way that it is not permanent? permanent? source_page: 1149
```

### question_1864 (question_block)

- `bm25`: 8.985
- `cosine_distance`: 0.326
- `hybrid_score`: 0.761
- `source_page`: 1154

```text
wave: wave_17 module: proxy_w17 question_id: proxy_w17.PJBPTFT variable_name: PJBPTFT question_text: Would you say that [NAME] 's current job is part-time or full-time? universe: if [GRIDVARIABLES.modetype = 1 | 2] // Mode is face-to-face or telephone And if [IProxy = 1] // Able to do a proxy interview for respondent And if [JBHAS = 1|JBOFF = 1] // Did paid work last week or no work last week but has a job And if [JBSEMP = 1] // Employee And if [JBHRS = DK] // Job hours not known routing_before: if [JBHRS = DK] // Job hours not known response_options: 1 Part-time Part-time 2 Full-time Full-time Page 1152 of 1165 source_page: 1154
```

