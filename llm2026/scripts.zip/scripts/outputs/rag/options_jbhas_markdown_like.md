# RAG Retrieval options_jbhas markdown_like

**Query:** What are the response options for variable JBHAS?

## Retrieved Chunks

### markdown_1181 (markdown_like)

- `bm25`: 2.292
- `cosine_distance`: 0.225
- `hybrid_score`: 0.899
- `source_page`: 741

```text
## currentemployment_w17
### currentemployment_w17.JBOFFY

Universe: if [JBHAS = 2] // Did not do any paid work last week And if [JBHAS = 2 AND JBOFF = 1] // Did not do paid work last week but does have a job

Question text: What was the main reason you were away from work last week?

Options: 1 Maternity leave Maternity leave 9 Paternity leave Paternity leave 10 Shared parental leave Shared parental leave 11 Adoption leave Adoption leave 2 Other leave/holiday Other leave/holiday 3 Sick/injured Sick/injured 4 Attending training course Attending training course 5 Laid off/on short time Laid off/on short time 6 On strike On strike 7 Other personal/family Other personal/family reasons reasons 97 Other reasons Other reasons Page 739 of 1165
```

### markdown_1094 (markdown_like)

- `bm25`: 1.886
- `cosine_distance`: 0.184
- `hybrid_score`: 0.82
- `source_page`: 684

```text
## annualeducationhistory_w17
### annualeducationhistory_w17.TRAINDAYS

Universe: if [ff_ivlolw = 1 | ff_everint = 1] // interviewed at prior wave or has been interviewed previously And if [TrainAny = 1] // Has done some training since last interview And if [TrainN = RESPONSE] // Number of training periods given

Question text: During the last 12 months, on how many days did you attend that training course?

Options: 
```

### markdown_1095 (markdown_like)

- `bm25`: 1.886
- `cosine_distance`: 0.184
- `hybrid_score`: 0.82
- `source_page`: 685

```text
## annualeducationhistory_w17
### annualeducationhistory_w17.TRAINHRS

Universe: if [ff_ivlolw = 1 | ff_everint = 1] // interviewed at prior wave or has been interviewed previously And if [TrainAny = 1] // Has done some training since last interview And if [TrainN = RESPONSE] // Number of training periods given

Question text: On average and not including breaks, lunch or travel time, how many hours [each/that] day did you spend on that course?

Options: 
```

