# RAG Retrieval options_jbhas naive

**Query:** What are the response options for variable JBHAS?

## Retrieved Chunks

### naive_2607 (naive)

- `bm25`: 3.235
- `cosine_distance`: 0.057
- `hybrid_score`: 0.974

```text
pe: choice
              Don't know: -1              Refused: -2            Inapplicable: -8       Missing: -9

Universe:    if [CURRENTEMPLOYMENT.JBHAS = 1 | CURRENTEMPLOYMENT.JBOFF = 1] // did paid work last
             week or did no paid work last week but has a job
Showcard: TBC
Text:        The pace at which you work
Options:
              1       A lot    A lot

              2       Some Some

              3       A        A
                      little   little

              4       None     None

Mixed Mode Alternatives
Web          Delete
Interview:   Showcard

Telephone Post-text Interviewer Instruction
Interview: REPEAT RESPONSE OPTIONS IF NECESSARY

             Delete
             Showcard

Use:         Ask WKAUT2




Question: workconditions_w17.WKAUT3                [ Autonomy over work manner ]

Module:      workconditions_w17
Source:      WERS

              Type: choice
              Don't know: -1              Refused: -2            Inapplicable: -8       Missin
```

### naive_2608 (naive)

- `bm25`: 3.235
- `cosine_distance`: 0.057
- `hybrid_score`: 0.974

```text
tions_w17
Source:      WERS

              Type: choice
              Don't know: -1              Refused: -2            Inapplicable: -8       Missing: -9

Universe:    if [CURRENTEMPLOYMENT.JBHAS = 1 | CURRENTEMPLOYMENT.JBOFF = 1] // did paid work last
             week or did no paid work last week but has a job
Showcard: TBC
Text:        How you do your work
Options:
              1       A lot    A lot

              2       Some Some

              3       A        A
                      little   little

              4       None     None

Mixed Mode Alternatives

                                                                                                Page 823 of 1165


Web          Delete
Interview:   Showcard

Telephone Post-text Interviewer Instruction
Interview: REPEAT RESPONSE OPTIONS IF NECESSARY

             Delete
             Showcard

Use:         Ask WKAUT3




Question: workconditions_w17.WKAUT4                      [ Autonomy over task order ]

Module:     
```

### naive_2609 (naive)

- `bm25`: 3.235
- `cosine_distance`: 0.057
- `hybrid_score`: 0.974

```text
             Showcard

Use:         Ask WKAUT3




Question: workconditions_w17.WKAUT4                      [ Autonomy over task order ]

Module:      workconditions_w17
Source:      WERS

               Type: choice
               Don't know: -1                 Refused: -2               Inapplicable: -8   Missing: -9

Universe:    if [CURRENTEMPLOYMENT.JBHAS = 1 | CURRENTEMPLOYMENT.JBOFF = 1] // did paid work last
             week or did no paid work last week but has a job
Showcard: TBC
Text:        The order in which you carry out tasks
Options:      1        A lot    A lot

              2        Some Some

              3        A        A
                       little   little

              4        None     None

Mixed Mode Alternatives
Web          Delete
Interview:   Showcard

Telephone Post-text Interviewer Instruction
Interview: REPEAT RESPONSE OPTIONS IF NECESSARY

             Delete
             Showcard

Use:         Ask WKAUT4




Question: workconditions_w17.WKAUT5  
```

