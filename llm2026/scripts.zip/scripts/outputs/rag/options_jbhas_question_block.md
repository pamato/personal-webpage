# RAG Retrieval options_jbhas question_block

**Query:** What are the response options for variable JBHAS?

## Retrieved Chunks

### question_1181 (question_block)

- `bm25`: 2.136
- `cosine_distance`: 0.423
- `hybrid_score`: 0.81
- `source_page`: 741

```text
wave: wave_17 module: currentemployment_w17 question_id: currentemployment_w17.JBOFFY variable_name: JBOFFY question_text: What was the main reason you were away from work last week? universe: if [JBHAS = 2] // Did not do any paid work last week And if [JBHAS = 2 AND JBOFF = 1] // Did not do paid work last week but does have a job routing_before: if [JBHAS = 2 AND JBOFF = 1] // Did not do paid work last week but does have a job response_options: 1 Maternity leave Maternity leave 9 Paternity leave Paternity leave 10 Shared parental leave Shared parental leave 11 Adoption leave Adoption leave 2 Other leave/holiday Other leave/holiday 3 Sick/injured Sick/injured 4 Attending training course Attending training course 5 Laid off/on short time Laid off/on short time 6 On strike On strike 7 Other personal/family Other personal/family reasons reasons 97 Other reasons Other reasons Page 739 of 1165 source_page: 741
```

### question_1179 (question_block)

- `bm25`: 1.849
- `cosine_distance`: 0.423
- `hybrid_score`: 0.736
- `source_page`: 739

```text
wave: wave_17 module: currentemployment_w17 question_id: currentemployment_w17.JBHAS variable_name: JBHAS question_text: Can I just check, did you do any paid work last week - that is in the seven days ending last Sunday - either as an employee or self-employed? Include casual work, Saturday jobs or earning money whilst using a website or digital platform. universe: Ask all routing_before: NA response_options: 1 Yes Yes 2 No No Page 737 of 1165 source_page: 739
```

### question_1180 (question_block)

- `bm25`: 1.849
- `cosine_distance`: 0.423
- `hybrid_score`: 0.736
- `source_page`: 740

```text
wave: wave_17 module: currentemployment_w17 question_id: currentemployment_w17.JBOFF variable_name: JBOFF question_text: Even though you weren't working did you have a job that you were away from last week? Page 738 of 1165 universe: if [JBHAS = 2] // Did not do any paid work last week routing_before: if [JBHAS = 2] // Did not do any paid work last week response_options: NA source_page: 740
```

## Teaching Answer

`currentemployment_w17.JBHAS` is asked to all respondents. It asks whether they did any paid work last week, including employee or self-employed work, casual work, Saturday jobs, or earning money through a website or digital platform. The response options are `1 Yes` and `2 No`.

`currentemployment_w17.JBOFF` is routed after `if [JBHAS = 2]`, meaning it is asked when the respondent did not do paid work last week.

