# RAG Retrieval route_jboff markdown_like

**Query:** What routing condition leads to question currentemployment_w17.JBOFF?

## Retrieved Chunks

### markdown_1180 (markdown_like)

- `bm25`: 2.292
- `cosine_distance`: 0.4
- `hybrid_score`: 0.82
- `source_page`: 740

```text
## currentemployment_w17
### currentemployment_w17.JBOFF

Universe: if [JBHAS = 2] // Did not do any paid work last week

Question text: Even though you weren't working did you have a job that you were away from last week? Page 738 of 1165

Options: 
```

### markdown_1181 (markdown_like)

- `bm25`: 2.292
- `cosine_distance`: 0.4
- `hybrid_score`: 0.82
- `source_page`: 741

```text
## currentemployment_w17
### currentemployment_w17.JBOFFY

Universe: if [JBHAS = 2] // Did not do any paid work last week And if [JBHAS = 2 AND JBOFF = 1] // Did not do paid work last week but does have a job

Question text: What was the main reason you were away from work last week?

Options: 1 Maternity leave Maternity leave 9 Paternity leave Paternity leave 10 Shared parental leave Shared parental leave 11 Adoption leave Adoption leave 2 Other leave/holiday Other leave/holiday 3 Sick/injured Sick/injured 4 Attending training course Attending training course 5 Laid off/on short time Laid off/on short time 6 On strike On strike 7 Other personal/family Other personal/family reasons reasons 97 Other reasons Other reasons Page 739 of 1165
```

### markdown_1182 (markdown_like)

- `bm25`: 2.292
- `cosine_distance`: 0.4
- `hybrid_score`: 0.82
- `source_page`: 742

```text
## currentemployment_w17
### currentemployment_w17.JOBCODECHK

Universe: if [JBHAS = 1 OR JBOFF = 1] // Has a job And if [ff_JOBCODE <> MIS] // Fed-forward job title and name of firm not missing

Question text: Last time we interviewed you on [ff_intdate], you reported the following [job/jobs]. Are you still doing [this job/each of these jobs]?

Options: 1 Yes Yes 2 No No
```

