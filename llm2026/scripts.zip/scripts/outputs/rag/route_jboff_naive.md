# RAG Retrieval route_jboff naive

**Query:** What routing condition leads to question currentemployment_w17.JBOFF?

## Retrieved Chunks

### naive_2331 (naive)

- `bm25`: 2.985
- `cosine_distance`: 0.38
- `hybrid_score`: 0.829

```text

           month) whether this work is full-time or part-time.
           *Answer yes if you were absent due to holiday, strike, sickness, maternity/paternity/adoption/shared
           parental leave, unpaid leave, lay-off or similar reason, provided you have a job to return to with the same
           employer.
           *Answer no if you are receiving redundancy payments and have no job to return to.

Use:        Ask JBOFF



if [JBHAS = 2 AND JBOFF = 1] // Did not do paid work last week but does have a job




   Question: currentemployment_w17.JBOFFY                               [ Reason off work last week ]

    Module:        currentemployment_w17
    Source:        BHPS

                    Type: choice
                    Don't know: -1                      Refused: -2                   Inapplicable: -8    Missing: -9

    Universe: if [JBHAS = 2] // Did not do any paid work last week
              And if [JBHAS = 2 AND JBOFF = 1] // Did not do paid work last week but does 
```

### naive_2339 (naive)

- `bm25`: 2.697
- `cosine_distance`: 0.368
- `hybrid_score`: 0.782

```text
     Inapplicable: -8       Missing: -9

    Universe: if [JBHAS = 1 OR JBOFF = 1] // Has a job
              And if [ff_JOBCODE = MIS] // Fed-forward job title and name of firm are missing
    Text:       In total, how many jobs do you have currently?
    Question Enter number of jobs
    Box
    Label:
    Use:        Ask MULTIJOBS




Question: currentemployment_w17.MULTIJOBSTOTAL                                [ Total number of all jobs ]

Module:     currentemployment_w17
Source:     UKHLS

              Type: Number                    Range: 0 .. 16
              Don't know: -1                 Refused: -2                      Inapplicable: -8        Missing: -9

Universe: if [JBHAS = 1 OR JBOFF = 1] // Has a job
Use:        If MULTIJOBS = DK|REF, compute MULTIJOBSTOTAL = 1;
            Else compute MULTIJOBSTOTAL = ((each JOBCODECHK = 1 + MULTIJOBSCHK) | MULTIJOBS;                     Page 741 of 1165


Loop for each [(new job reported this wave) MULTIJOBS > 0 | MULTIJOBSCHK > 0]
```

### naive_2342 (naive)

- `bm25`: 2.697
- `cosine_distance`: 0.368
- `hybrid_score`: 0.782

```text
ew job reported this wave) MULTIJOBS > 0 | MULTIJOBSCHK > 0]

   Universe: if [JBHAS = 1 OR JBOFF = 1] // Has a job
   Text:      What is the name of the firm or organisation where you work in this job?
   Help:      If you do not work at a firm/organisation, please enter self-employment or the name of your
              business/company.
   Use:       Ask ALLJOBSFIRM



END LOOP (ALLJOBSTITLELoop)




Question: currentemployment_w17.JOBCODE                         [ Job title and name of firm ]

Module:    currentemployment_w17                                                                                      Page 742 of 1165


Source:    UKHLS

            Type: multichoice
            Don't know: -1                Refused: -2           Inapplicable: -8   Missing: -9

Universe: if [JBHAS = 1 OR JBOFF = 1] // Has a job
Options:    1       [Alljobstitle] at
                                                 Job number 1
                    [Alljobsfirm] ,

            2       [Alljobst
```

