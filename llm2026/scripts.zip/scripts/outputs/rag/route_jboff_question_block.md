# RAG Retrieval route_jboff question_block

**Query:** What routing condition leads to question currentemployment_w17.JBOFF?

## Retrieved Chunks

### question_1180 (question_block)

- `bm25`: 2.947
- `cosine_distance`: 0.368
- `hybrid_score`: 0.835
- `source_page`: 740

```text
wave: wave_17 module: currentemployment_w17 question_id: currentemployment_w17.JBOFF variable_name: JBOFF question_text: Even though you weren't working did you have a job that you were away from last week? Page 738 of 1165 universe: if [JBHAS = 2] // Did not do any paid work last week routing_before: if [JBHAS = 2] // Did not do any paid work last week response_options: NA source_page: 740
```

### question_1181 (question_block)

- `bm25`: 2.947
- `cosine_distance`: 0.368
- `hybrid_score`: 0.835
- `source_page`: 741

```text
wave: wave_17 module: currentemployment_w17 question_id: currentemployment_w17.JBOFFY variable_name: JBOFFY question_text: What was the main reason you were away from work last week? universe: if [JBHAS = 2] // Did not do any paid work last week And if [JBHAS = 2 AND JBOFF = 1] // Did not do paid work last week but does have a job routing_before: if [JBHAS = 2 AND JBOFF = 1] // Did not do paid work last week but does have a job response_options: 1 Maternity leave Maternity leave 9 Paternity leave Paternity leave 10 Shared parental leave Shared parental leave 11 Adoption leave Adoption leave 2 Other leave/holiday Other leave/holiday 3 Sick/injured Sick/injured 4 Attending training course Attending training course 5 Laid off/on short time Laid off/on short time 6 On strike On strike 7 Other personal/family Other personal/family reasons reasons 97 Other reasons Other reasons Page 739 of 1165 source_page: 741
```

### question_1182 (question_block)

- `bm25`: 2.542
- `cosine_distance`: 0.4
- `hybrid_score`: 0.744
- `source_page`: 742

```text
wave: wave_17 module: currentemployment_w17 question_id: currentemployment_w17.JOBCODECHK variable_name: JOBCODECHK question_text: Last time we interviewed you on [ff_intdate], you reported the following [job/jobs]. Are you still doing [this job/each of these jobs]? universe: if [JBHAS = 1 OR JBOFF = 1] // Has a job And if [ff_JOBCODE <> MIS] // Fed-forward job title and name of firm not missing routing_before: if [ff_JOBCODE <> MIS] // Fed-forward job title and name of firm not missing response_options: 1 Yes Yes 2 No No source_page: 742
```

## Teaching Answer

`currentemployment_w17.JBHAS` is asked to all respondents. It asks whether they did any paid work last week, including employee or self-employed work, casual work, Saturday jobs, or earning money through a website or digital platform. The response options are `1 Yes` and `2 No`.

`currentemployment_w17.JBOFF` is routed after `if [JBHAS = 2]`, meaning it is asked when the respondent did not do paid work last week.

