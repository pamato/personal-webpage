# RAG Retrieval who_jbhas markdown_like

**Query:** In the Understanding Society questionnaire, who is asked currentemployment_w17.JBHAS?

## Retrieved Chunks

### markdown_1181 (markdown_like)

- `bm25`: 2.697
- `cosine_distance`: 0.423
- `hybrid_score`: 0.81
- `source_page`: 741

```text
## currentemployment_w17
### currentemployment_w17.JBOFFY

Universe: if [JBHAS = 2] // Did not do any paid work last week And if [JBHAS = 2 AND JBOFF = 1] // Did not do paid work last week but does have a job

Question text: What was the main reason you were away from work last week?

Options: 1 Maternity leave Maternity leave 9 Paternity leave Paternity leave 10 Shared parental leave Shared parental leave 11 Adoption leave Adoption leave 2 Other leave/holiday Other leave/holiday 3 Sick/injured Sick/injured 4 Attending training course Attending training course 5 Laid off/on short time Laid off/on short time 6 On strike On strike 7 Other personal/family Other personal/family reasons reasons 97 Other reasons Other reasons Page 739 of 1165
```

### markdown_1797 (markdown_like)

- `bm25`: 2.697
- `cosine_distance`: 0.423
- `hybrid_score`: 0.81
- `source_page`: 1116

```text
## endofinterview_w17
### endofinterview_w17.VOUCHLETTER

Universe: if [GRIDVARIABLES.ModeType = 1 | 2] // Mode is face-to-face or telephone And if [(ff_ivlolw = 1|2|3|4|5 & ff_everint = 1|2) & GRIDVARIABLES.RJRFLAG = 0] // Not a new joiner and not a rejoiner

Question text: Did you receive an Understanding Society advance letter with a voucher? {if ff_ivlolw = 1)} Did you receive an Understanding Society advance letter? {if ff_ivlolw = 2|3|4|5)}

Options: 1 Yes Yes 2 No No Page 1114 of 1165
```

### markdown_1179 (markdown_like)

- `bm25`: 2.292
- `cosine_distance`: 0.452
- `hybrid_score`: 0.714
- `source_page`: 739

```text
## currentemployment_w17
### currentemployment_w17.JBHAS

Universe: Ask all

Question text: Can I just check, did you do any paid work last week - that is in the seven days ending last Sunday - either as an employee or self-employed? Include casual work, Saturday jobs or earning money whilst using a website or digital platform.

Options: 1 Yes Yes 2 No No Page 737 of 1165
```

