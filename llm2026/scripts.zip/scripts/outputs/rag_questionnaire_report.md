# Questionnaire RAG

Mode: live OpenRouter answer generation via ellmer

## Retrieval Claim

For RAG, the unit of retrieval should match the unit of meaning. In a questionnaire, that is often a question block plus routing and response metadata.

## Hit Summary

               query_id     store_type hit_at_3
 economic_activity_vars  markdown_like     TRUE
          options_jbhas  markdown_like     TRUE
            route_jboff  markdown_like     TRUE
              who_jbhas  markdown_like     TRUE
 economic_activity_vars          naive     TRUE
          options_jbhas          naive     TRUE
            route_jboff          naive     TRUE
              who_jbhas          naive    FALSE
 economic_activity_vars question_block     TRUE
          options_jbhas question_block     TRUE
            route_jboff question_block     TRUE
              who_jbhas question_block     TRUE

## Metadata Filter

The metadata-filtered retrieval restricts to `wave_17`, adult respondent type, and the current/non-employment module groups before searching.

## Extractive Answer From Question-Block Retrieval

`currentemployment_w17.JBHAS` is asked to all respondents. It asks whether they did any paid work last week, including employee or self-employed work, casual work, Saturday jobs, or earning money through a website or digital platform. The response options are `1 Yes` and `2 No`.

`currentemployment_w17.JBOFF` is routed after `if [JBHAS = 2]`, meaning it is asked when the respondent did not do paid work last week.

## Files

- `rag_question_blocks.csv`
- `rag_retrieval_comparison.csv`
- `rag_hit_summary.csv`
- `rag_strategy_comparison.csv`
- `rag_metadata_filter_demo.csv`
