/**
* @requires jQuery ($)
* Define relevant functions
*/

/**
 * Load required mermaid.js library
 * Initialize the mermaid.js library on all ".formr-mermaid" elements
 * 
 * @param {String} url URL to JS library
 */
 function loadMermaidJs(url) {
    // Create a <script> tag that will be used to include the mermaid JS library in the webpage
    var script = document.createElement('script');
    script.src = url;
    
    // Define a callback function to be called once the script is loaded
    // Our callback function will search for all web page elements with class .formr-mermaid
    // and use its text content to initialize the mermaid.js library
    script.onload = function () {
        mermaid.initialize({startOnLoad:false, securityLevel:'loose'});
        $(document).ready(function() {
            $(".item-note .mermaid").each(function() {
                var $this = $(this);
                $this.text($this.text());
                $this.show();
            });
            mermaid.init({noteMargin: 10}, ".item-note .mermaid");
        });
    };
    
    //append the created <script> tag to the <head> element of the DOM
    document.head.appendChild(script); 
}

/**
 * Appends to the pagination buttons extra divs if a user has already completed pages previously
 * Takes the value of div id #lastpage and compares to the last div number in the pagination
 * e.g. <div class="hidden" id="lastpage" >8</div>
 */ 


// removes the first 2 links and the 'back to' link
function appendPaginationButtonsText() {
    //remove the first 2 links and the 'back to' link
    $('.btn-group').find('.btn:lt(3)').remove();
    // takes the numeric value from the lastpage div
    var pagination_last_page = $('#lastpage').text();
    // only need to run if pages visited if 4 or greater
    if (pagination_last_page > 4) {
        // get the numeric value of the last page button data attribute (e.g. data-page="3")
        var pagination_current_page = $('.page-buttons .btn-default:last').data("page");
        // checks if the last page value is grerater then the current page
        if (pagination_last_page > pagination_current_page) {
            // increment the current page by 1 (i.e. the next page)
            pagination_current_page = pagination_current_page + 1;
            //loop through until the current page value is equal to the last page
            for(var i = pagination_current_page; i <= pagination_last_page; i++) {
               // insert new buttons/links
               var html = "<a class='btn btn-default btn-page-" + i + "' data-page='" + i + "' href='https://ukhls.formr.org/" + i + "/'> " + i + " </a>";
                $(".page-buttons").append(html);
            }
        }
    }
}



/**
 * Change the texts on the paginations buttons
 * Instead of the default numbering, use 'texts' representing the various 'categories of interest'
 */ 
function changePaginationButtonsText() {
    // Label of the text element indicating the current page/position within the EHC
    $('.page-text').text('Page ');
    // Label of the text element next to the page labels
    $('.back-text').text('Back to ');
    // Label for each of the pages
    var pages = ['Welcome', 'Video', 'Instructions', 'Birth', 'Residences', 'Education', 'Jobs', 'Relationships', 'Fertility History', 'Mental Health', 'Physical Health','Complete Calendar'];
    var $study = $('.study-name-EHC_survey');
    // assignment of page labels to their corresponding page numbers
    for (var i in pages) {
        var pageNo = i*1 + 1;
        var pageLabel = ' ' + pages[i] + ' ';
        $study.find('.page-buttons .btn-page-' + pageNo).text(pageLabel);
    }
}


/**
 * Limit the start dates in each calendar to the 'indicated start date'
 * 
 * @param {String} selector The selector of the DOM element containing the 'indicated start date' as TEXT
 */
 function limitStartDate(selector) {
    // Get the exact value of the 'Start Date' by reading the text content of the web page element
    // Please ensure that this selector (class name or ID, "16bday" in our case) is defined when creating the items in the item sheet
    // Date format: yyyy-mm
     var birthday = $(selector).text();
    // var birthday = $(selector).id();
    // All input elements for the dates will then have the above value as the minimum selectable date
    $('input[type=month]').prop('min', function() {
        var arr = birthday.split('-');
        arr.push('01');
        return arr.join('-');
    }); 
 }
 
 function limitEndDate(datefrom_name_prefix, current_name_prefix) {
    // Select the web page element for the 'Start Date' and the Marker for current Events
    // Notice that the selector has be string 'name^=' which means all web page elements with names begining with the inidicated string (prefix) should be selected
    var $dateFrom = $("input[name^='"+datefrom_name_prefix+"']");
    var $currentEvent = $("input[name^='"+current_name_prefix+"']");
    
    // If the elements are not found, no need to proceeed
    if (!$dateFrom.length | !$currentEvent.length) {
        return;
    }
    
    // All input elements for the dates will then have the above value as the minimum selectable date
    $('input[type=month]').prop('min', function() {
        var arr = birthday.split('-');
        arr.push('01');
        return arr.join('-');
    }); 
 }
 
 /**
 * Set the mimimum "End Date" based on the selection of the "Start Date"
 * 
 * @param {String} datefrom_name_prefix The prefix of the name of the web page element for the "Start Date" for each event row.
 * @param {String} current_name_prefix The prefix of the name of the web page element that indicates that an entered event is "current" for each row
 */
function setMinEndDate(datefrom_name_prefix, current_name_prefix) {
    // Select the web page element for the 'Start Date' and the Marker for current Events
    // Notice that the selector has be string 'name^=' which means all web page elements with names begining with the inidicated string (prefix) should be selected
    var $dateFrom = $("input[name^='"+datefrom_name_prefix+"']");
    var $currentEvent = $("input[name^='"+current_name_prefix+"']");
    
    // If the elements are not found, no need to proceeed
    if (!$dateFrom.length | !$currentEvent.length) {
        return;
    }
    
    // Bind the 'change' event on the Start Date element
    // So when the Start Date changes, use the selected value as the minimum value for the End Date
    $dateFrom.bind('change', function() {
        var $ele = $(this);
        var datefrom = $ele.val();
        if (!datefrom) {
            return;
        }

        var number = $ele.attr('name').replace(datefrom_name_prefix, '');
        
        // Get the input elements containing the End Date and 'Current' marker
        var $dateTo = $('input[name=dateto_'+number+']');
        var $current = $('input[name="'+current_name_prefix+number+'[]"]');
   
        // set the minimum date for 'End Date'
        $dateTo.prop('min', datefrom);
        if (!$dateTo.val() && !$current.is(':checked')) {
            $dateTo.val(datefrom)
        }

        // When 'End Date' changes, check if it is the same as start date and display a note for the user
        $dateTo.bind('change', function() {
           var dateto = $(this).val();
           var msgId = 'alert-set-min-end-date-' + number;
           var lineNumber = number.replace(/[^0-9.]+/g, '');
           
           /*if (datefrom && dateto && datefrom == dateto) {
               var msg = '<i class="fa fa-info"></i> Start and End dates are equal for event in Line ' + lineNumber;
               $('#'+msgId).remove();
               $('.alerts-container').append('<div id="'+msgId+'" class="alert alert-info alert-dismissable">' + msg + '</div>');
               $("html, body").animate({ scrollTop: 0 }, "slow");
           } else {
               $('#'+msgId).remove();
           }*/
        }).trigger('change');
        
    })
    
    /*
    // If the user is revisiting a category with an already entered start date, trigger the 'change' event to set the minumum date
    if ($dateFrom.val()) {
        $dateFrom.trigger('change');
    }
    */
}

/** Disable "End Date" for the various categories if "Current" is selected
 * 
 * @param {String} current_name_prefix The name of the web page element that indicates that a row entry is "current"
 */
function disableEndDate(current_name_prefix) {
    $("input[name^='"+current_name_prefix+"']").bind('click', function() {
       // assign the 'current' input element to the $ele variable
       var $ele = $(this);
       // get the corresponding line (row) number
       var number = $ele.attr('name').replace(current_name_prefix, '').replace('[]', '');
       
       // Remove any messages that this row might have generated
       var msgId = 'alert-set-min-end-date-' + number;
       $('#'+msgId).remove();
       
       // If the input element (square) is 'Checked', then disable the 'End Date' for that row
       // Otherwise enable the 'End Date'
       if ($ele.is(':checked')) {
           $("input[name=dateto_"+number+"]").val('').prop('disabled', true);
       } else {
            $("input[name=dateto_"+number+"]").prop('disabled', false);
       }
    });
}

function disableStartDate(current_name_prefix) {
    $("input[name^='"+current_name_prefix+"']").bind('click', function() {
       // assign the 'current' input element to the $ele variable
       var $ele = $(this);
       // get the corresponding line (row) number
       var number = $ele.attr('name').replace(current_name_prefix, '').replace('[]', '');
       
       // If the input element (square) is 'Checked', then disable the 'Start Date' for that row
       // Otherwise enable the 'Start Date'
       if ($ele.is(':checked')) {
           $("input[name=datefrom_"+number+"]").val('').prop('disabled', true);
       } else {
            $("input[name=datefrom_"+number+"]").prop('disabled', false);
       }
    });
}


/**
 * On form submit, check if user has entered an End Date or indicated
 * if an event is current
 * 
 */
function formSubmitCallback() {
    $('form.main_formr_survey').on('submit', function(e) {
        // Define the various categories of interest and the 'prefixes' of the 'names' of the input elements
        // @todo explain each prefix
        var categories = {
            'residence':  ['datefrom_R', 'dateto_R', 'current_residence_R'],
            'education': ['datefrom_E', 'dateto_E', 'current_education_E'],
            'occupation': ['datefrom_O', 'dateto_O', 'current_occupation_O'],
            'partner':    ['datefrom_P', 'dateto_P', 'current_partner_P'],
            //'child':    ['datefrom_C', 'dateto_C', 'current_child_C'],
            'issue_mental':    ['datefrom_PH', 'dateto_PH', 'current_mental_PH'],
            'issue_physical':    ['datefrom_IH', 'dateto_IH', 'current_physical_IH']
        };
        
        // array to store validation messages
        var messages = [];
        // obtain the form object from the web page
        var $form = $(this);
        
        // Foreach Category check all the rows
        for (var cn in categories) {
            var category = categories[cn];
            
            // For each row (There are 14 rows for each category defined in the Items Sheet) in a category, check if the 'End Date' is entered OR if the "Current" checkbox is selected
            for (var i = 1; i <= 24; i++) {
                // Define the various web page elements of interest
                var startfield = category[0] + i;
                var endfield = category[1] + i;
                var currentfield = category[2] + i;
                
                var $startfield = $form.find('input[name^='+startfield+']');
                var $endfield   = $form.find('input[name^='+endfield+']');
                var $currentfield   = $form.find('input[name^='+currentfield+']');
                
                if (!$endfield.length || !$currentfield.length || $endfield.prop('disabled')) {
                    continue;
                }
                
                // compute the 'End Date' Date object
                var td = $endfield.val().split('-');
                var todate = new Date(td[0], td[1]-1, 1, 1, 1, 1, 1);
                // send a pop-up message if the user forgot to enter an end date or indicated the event as a current one
                if ($.trim($endfield.val()) === '' && !$currentfield.prop('checked')) {
                    messages.push('Please indicate an end date or confirm that the event is a current in Line ' + '<b>' + i + '</b>');
                }
            }
            
        }
        
        if (messages.length) { // There are error messages
            // enable submit button
            $form.find('.form-group.item-submit button').prop('disabled', false).find('.fa-spinner').remove();
            
            // Show the message to the user
            bootstrap_modal('Date Error', '<div class="alert alert-danger">' + messages.join('<br />') + '</div>');
            
            // Prevent form submission
            e.preventDefault();
            return false;
        } else {
            return true;
        }
    });
}

/**
 * Warning message to remind respondents to use navigation tabs to move back and forth in the EHC
 */

/*function alertbutton() {
    var close = document.getElementsByClassName("closebtn");
    var i;
    
    for (i = 0; i < close.length; i++) {
      close[i].onclick = function(){
        var div = this.parentElement;
        div.style.opacity = "0";
        setTimeout(function(){ div.style.display = "none"; }, 600);
      }
    }
}*/

function alertbutton(){
    $(".alerttemp").fadeIn(1000).fadeOut(5000); 
}


/** Run relevant JavaScript functions when the web page is ready **/

// Load the mermaid JavaScript library
loadMermaidJs("https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js");

$(document).ready(function() {
    
    // Append pagination buttons
    appendPaginationButtonsText();
    
    // Change the texts on the paginating buttons
    changePaginationButtonsText();
    
    // Limit start date
    limitStartDate('.item-note .16bday');
    
    // Adjust the date fields of the various categories as follows: 
    //    1. If an event is marked as "current", disable the "End Date" input field
    //    2. Set the minimum selectable date for "End Date", based on the selection of the "Begin Date"
    
    // Residences Domain:
    disableEndDate('current_residence_');
    setMinEndDate('datefrom_', 'current_residence_');
    
    // Education Domain:
    disableEndDate('current_education_');
    setMinEndDate('datefrom_', 'current_education_');
    
    // Occupation Domain:
    disableEndDate('current_occupation_');
    setMinEndDate('datefrom_', 'current_occupation_');
    
    // Relationship Domain:
    disableEndDate('current_partner_');
    setMinEndDate('datefrom_', 'current_partner_');
    
    // Children Domain:
    disableEndDate('current_child_');
    setMinEndDate('datefrom_', 'current_child_');
    
    // Health: Mental 
    disableEndDate('current_mental_');
    setMinEndDate('datefrom_', 'current_mental_');
    
    // Health: Physical 
    disableEndDate('current_physical_');
    setMinEndDate('datefrom_', 'current_physical_');
    
    // Remind respondents to navigate EHC:
    alertbutton();
    
    
});

// Webshim validation rule
// On formr submit, check if all the  dates are valid and in order and show appropriate error messages
webshim.ready('forms forms-ext dom-extend form-validators', formSubmitCallback);

// activate English language
webshim.activeLang('en');
if (webshim.updatePolyfill) {
    webshim.updatePolyfill('es5 es6 forms forms-ext geolocation'); 
}